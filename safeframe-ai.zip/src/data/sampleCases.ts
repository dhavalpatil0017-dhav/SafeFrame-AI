import { IncidentCase } from '../types';

// High-fidelity CCTV Frame SVG 1: CAM-04 Data Center Corridor
const cctvFrame1Svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 450" width="800" height="450">
  <defs>
    <radialGradient id="nightVignette" cx="50%" cy="50%" r="70%">
      <stop offset="30%" stop-color="#0e1726" stop-opacity="0.3"/>
      <stop offset="90%" stop-color="#030712" stop-opacity="0.95"/>
    </radialGradient>
    <pattern id="cctvScan" width="100" height="4" patternUnits="userSpaceOnUse">
      <line x1="0" y1="0" x2="100" y2="0" stroke="#000000" stroke-width="1.2" opacity="0.35"/>
    </pattern>
    <filter id="noiseFilter">
      <feTurbulence type="fractalNoise" baseFrequency="0.8" numOctaves="3" result="noise"/>
      <feColorMatrix type="matrix" values="0 0 0 0 0.1  0 0 0 0 0.15  0 0 0 0 0.2  0 0 0 0.08 0"/>
      <feComposite in2="SourceGraphic" in="gl" operator="over"/>
    </filter>
  </defs>

  <!-- Background Corridor -->
  <rect width="800" height="450" fill="#070c18"/>

  <!-- Perspective Hallway Walls -->
  <polygon points="0,0 240,140 240,310 0,450" fill="#0a1224" stroke="#14213d" stroke-width="2"/>
  <polygon points="800,0 560,140 560,310 800,450" fill="#091020" stroke="#14213d" stroke-width="2"/>
  <!-- Floor -->
  <polygon points="0,450 240,310 560,310 800,450" fill="#0b1329"/>
  <!-- Ceiling with Fluorescent Strip Fixtures -->
  <polygon points="0,0 240,140 560,140 800,0" fill="#050a14"/>
  <line x1="360" y1="140" x2="330" y2="0" stroke="#334155" stroke-width="4" opacity="0.6"/>
  <line x1="440" y1="140" x2="470" y2="0" stroke="#334155" stroke-width="4" opacity="0.6"/>

  <!-- Server Racks (Right Wall) with LED blinks -->
  <rect x="580" y="160" width="30" height="120" fill="#0d1b33" stroke="#1e293b"/>
  <rect x="630" y="170" width="35" height="150" fill="#0d1b33" stroke="#1e293b"/>
  <rect x="685" y="180" width="45" height="180" fill="#0d1b33" stroke="#1e293b"/>
  <!-- Server LED lights -->
  <circle cx="586" cy="180" r="1.5" fill="#10b981"/>
  <circle cx="586" cy="190" r="1.5" fill="#06b6d4"/>
  <circle cx="586" cy="205" r="1.5" fill="#ef4444"/>
  <circle cx="638" cy="190" r="2" fill="#10b981"/>
  <circle cx="638" cy="205" r="2" fill="#f59e0b"/>
  <circle cx="638" cy="225" r="2" fill="#10b981"/>
  <circle cx="695" cy="200" r="2.5" fill="#ef4444"/>
  <circle cx="695" cy="215" r="2.5" fill="#06b6d4"/>

  <!-- Left Door Ajar (Access Control Breach point) -->
  <polygon points="120,400 120,80 180,120 180,340" fill="#0f1f3d" stroke="#22d3ee" stroke-width="1.5" stroke-opacity="0.6"/>
  <rect x="185" y="210" width="6" height="14" fill="#ef4444" rx="1"/> <!-- Door latch tamper point -->

  <!-- Crouching Intruder Silhouette -->
  <g transform="translate(340, 210)">
    <!-- Shadow -->
    <ellipse cx="60" cy="95" rx="45" ry="12" fill="#000000" opacity="0.7"/>
    <!-- Body crouching -->
    <path d="M 30,55 Q 40,25 65,30 Q 90,35 85,65 Q 80,95 45,90 Z" fill="#030712"/>
    <!-- Hooded Head -->
    <circle cx="48" cy="22" r="15" fill="#030712"/>
    <path d="M 40,15 Q 52,8 60,18 Q 50,32 38,26 Z" fill="#0a0f1d"/>
    <!-- Backpack -->
    <ellipse cx="75" cy="45" rx="14" ry="18" fill="#1e293b" opacity="0.9"/>
    <!-- Extended Arm holding cylindrical object -->
    <path d="M 50,50 L 25,65 L 12,68" stroke="#030712" stroke-width="7" stroke-linecap="round"/>
    <rect x="5" y="62" width="16" height="6" fill="#64748b" transform="rotate(-15 10 65)"/>
  </g>

  <!-- Forensic AI Bounding Box Overlay -->
  <rect x="330" y="200" width="140" height="120" fill="none" stroke="#2dd4bf" stroke-width="1.5" stroke-dasharray="4,3"/>
  <rect x="330" y="182" width="130" height="18" fill="#134e4a"/>
  <text x="335" y="195" font-family="monospace" font-size="11" fill="#5eead4" font-weight="bold">TARGET: SUBJ_01 [0.94]</text>

  <!-- Bounding Box on Tampered Lock -->
  <rect x="110" y="200" width="85" height="30" fill="none" stroke="#f43f5e" stroke-width="1.2" stroke-dasharray="3,3"/>
  <rect x="110" y="184" width="82" height="16" fill="#881337"/>
  <text x="114" y="196" font-family="monospace" font-size="9" fill="#fecdd3" font-weight="bold">ANOMALY: DOOR_AJAR</text>

  <!-- Vignette & Scanlines -->
  <rect width="800" height="450" fill="url(#nightVignette)"/>
  <rect width="800" height="450" fill="url(#cctvScan)"/>

  <!-- CCTV OSD Overlays -->
  <rect x="20" y="20" width="310" height="28" fill="#000000" opacity="0.75" rx="3"/>
  <circle cx="34" cy="34" r="5" fill="#ef4444">
    <animate attributeName="opacity" values="1;0.2;1" dur="1.8s" repeatCount="indefinite"/>
  </circle>
  <text x="46" y="38" font-family="monospace" font-size="12" fill="#2dd4bf" font-weight="bold">CAM-04 [REC] SERVER_VAULT_B</text>

  <!-- Timestamp Top Right -->
  <rect x="530" y="20" width="250" height="28" fill="#000000" opacity="0.75" rx="3"/>
  <text x="542" y="38" font-family="monospace" font-size="12" fill="#f8fafc">2026-10-25 02:14:18.422 UTC</text>

  <!-- Telemetry Lower Left -->
  <text x="25" y="430" font-family="monospace" font-size="10" fill="#94a3b8">FPS: 24.0 | RES: 1080P H.265 | BITRATE: 4120 Kbps | SENSOR: SONY-STARVIS</text>
  <text x="660" y="430" font-family="monospace" font-size="10" fill="#2dd4bf">SAFEFRAME VERIFIED</text>
</svg>`;

// High-fidelity CCTV Frame SVG 2: CAM-01 Perimeter Loading Bay Gate
const cctvFrame2Svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 450" width="800" height="450">
  <defs>
    <radialGradient id="gateVignette" cx="50%" cy="50%" r="70%">
      <stop offset="30%" stop-color="#0a1324" stop-opacity="0.2"/>
      <stop offset="90%" stop-color="#020617" stop-opacity="0.95"/>
    </radialGradient>
    <pattern id="cctvScan2" width="100" height="4" patternUnits="userSpaceOnUse">
      <line x1="0" y1="0" x2="100" y2="0" stroke="#000000" stroke-width="1.2" opacity="0.35"/>
    </pattern>
  </defs>

  <!-- Outdoor Night Sky & Ground -->
  <rect width="800" height="260" fill="#050a14"/>
  <rect y="260" width="800" height="190" fill="#091122"/>

  <!-- Wet Asphalt Reflections -->
  <ellipse cx="400" cy="380" rx="280" ry="40" fill="#0f1f3d" opacity="0.6"/>

  <!-- Perimeter Security Fence (Chain link silhouette) -->
  <line x1="0" y1="260" x2="800" y2="260" stroke="#334155" stroke-width="3"/>
  <line x1="0" y1="160" x2="800" y2="160" stroke="#1e293b" stroke-width="2"/>
  <line x1="100" y1="140" x2="100" y2="260" stroke="#475569" stroke-width="4"/>
  <line x1="250" y1="140" x2="250" y2="260" stroke="#475569" stroke-width="4"/>
  <line x1="600" y1="140" x2="600" y2="260" stroke="#475569" stroke-width="4"/>
  <line x1="720" y1="140" x2="720" y2="260" stroke="#475569" stroke-width="4"/>

  <!-- High-mast Security Floodlight (Left) creating glare -->
  <circle cx="160" cy="70" r="8" fill="#fef08a"/>
  <polygon points="160,70 50,380 340,380" fill="#fef08a" opacity="0.08"/>

  <!-- Idling Dark Commercial Van (Center Right) -->
  <g transform="translate(320, 195)">
    <!-- Van Body -->
    <path d="M 30,130 L 260,130 L 260,35 L 180,35 L 140,65 L 30,70 Z" fill="#0c162c" stroke="#1e293b" stroke-width="2"/>
    <!-- Tinted Windows -->
    <polygon points="175,42 142,68 185,68 185,42" fill="#030712"/>
    <!-- Wheels -->
    <circle cx="75" cy="135" r="22" fill="#020617" stroke="#334155" stroke-width="4"/>
    <circle cx="215" cy="135" r="22" fill="#020617" stroke="#334155" stroke-width="4"/>
    <circle cx="75" cy="135" r="8" fill="#64748b"/>
    <circle cx="215" cy="135" r="8" fill="#64748b"/>
    <!-- Dull Red Taillight Reflection -->
    <rect x="255" y="80" width="6" height="25" fill="#dc2626" rx="2"/>
    <ellipse cx="270" cy="140" rx="35" ry="12" fill="#ef4444" opacity="0.25"/>
    <!-- Obscured License Plate Area -->
    <rect x="240" y="110" width="22" height="10" fill="#334155"/>
  </g>

  <!-- Motion Bounding Box on Idling Vehicle -->
  <rect x="330" y="210" width="280" height="145" fill="none" stroke="#f59e0b" stroke-width="1.5" stroke-dasharray="4,3"/>
  <rect x="330" y="192" width="165" height="18" fill="#78350f"/>
  <text x="335" y="205" font-family="monospace" font-size="10" fill="#fde68a" font-weight="bold">VEHICLE_ALERT: IDLE &gt; 8M</text>

  <!-- Vignette & Scanlines -->
  <rect width="800" height="450" fill="url(#gateVignette)"/>
  <rect width="800" height="450" fill="url(#cctvScan2)"/>

  <!-- CCTV OSD Overlays -->
  <rect x="20" y="20" width="310" height="28" fill="#000000" opacity="0.75" rx="3"/>
  <circle cx="34" cy="34" r="5" fill="#ef4444">
    <animate attributeName="opacity" values="1;0.2;1" dur="1.8s" repeatCount="indefinite"/>
  </circle>
  <text x="46" y="38" font-family="monospace" font-size="12" fill="#2dd4bf" font-weight="bold">CAM-01 [REC] PERIMETER_GATE_N</text>

  <!-- Timestamp Top Right -->
  <rect x="530" y="20" width="250" height="28" fill="#000000" opacity="0.75" rx="3"/>
  <text x="542" y="38" font-family="monospace" font-size="12" fill="#f8fafc">2026-10-25 02:08:44.119 UTC</text>

  <!-- Telemetry Lower Left -->
  <text x="25" y="430" font-family="monospace" font-size="10" fill="#94a3b8">WEATHER: LIGHT RAIN | IR_FILTER: OFF | SENSOR: THERMAL/OPT DUAL</text>
  <text x="660" y="430" font-family="monospace" font-size="10" fill="#2dd4bf">SAFEFRAME VERIFIED</text>
</svg>`;

// High-fidelity CCTV Frame SVG 3: CAM-09 Emergency Stairwell Exit
const cctvFrame3Svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 450" width="800" height="450">
  <defs>
    <radialGradient id="stairVignette" cx="50%" cy="50%" r="70%">
      <stop offset="30%" stop-color="#0a1220" stop-opacity="0.3"/>
      <stop offset="90%" stop-color="#020617" stop-opacity="0.95"/>
    </radialGradient>
    <pattern id="cctvScan3" width="100" height="4" patternUnits="userSpaceOnUse">
      <line x1="0" y1="0" x2="100" y2="0" stroke="#000000" stroke-width="1.2" opacity="0.35"/>
    </pattern>
  </defs>

  <!-- Concrete Stairwell Walls -->
  <rect width="800" height="450" fill="#0a1324"/>
  <!-- Diagonal Stairs -->
  <polygon points="0,450 350,220 500,220 800,450" fill="#0f1d38" stroke="#1e293b"/>
  <polygon points="350,220 500,220 500,100 350,100" fill="#070d18"/>

  <!-- Metal Railings -->
  <line x1="80" y1="450" x2="380" y2="240" stroke="#64748b" stroke-width="4"/>
  <line x1="160" y1="450" x2="160" y2="390" stroke="#475569" stroke-width="3"/>
  <line x1="260" y1="380" x2="260" y2="320" stroke="#475569" stroke-width="3"/>
  <line x1="360" y1="300" x2="360" y2="240" stroke="#475569" stroke-width="3"/>

  <!-- Exit Door (Propped open with wedge) -->
  <g transform="translate(380, 80)">
    <!-- Door Frame -->
    <rect x="0" y="0" width="120" height="160" fill="#050a14" stroke="#334155" stroke-width="3"/>
    <!-- Door Ajar Angle -->
    <polygon points="0,0 35,20 35,175 0,160" fill="#1e293b" stroke="#0284c7" stroke-width="2"/>
    <!-- Door Wedge / Prop Object -->
    <polygon points="25,175 42,175 42,165" fill="#f97316"/>
    <!-- Emergency Push Bar -->
    <rect x="8" y="80" width="20" height="5" fill="#ef4444"/>
    <!-- Green Emergency Exit Sign (Glowing) -->
    <rect x="35" y="-25" width="50" height="20" fill="#065f46" rx="2"/>
    <text x="44" y="-11" font-family="sans-serif" font-size="10" fill="#34d399" font-weight="bold">EXIT</text>
  </g>

  <!-- Flashing Strobe Siren Light (Top Left) -->
  <circle cx="120" cy="60" r="12" fill="#f43f5e" opacity="0.9"/>
  <ellipse cx="200" cy="180" rx="140" ry="70" fill="#f43f5e" opacity="0.12"/>

  <!-- Bounding Box on Propped Door -->
  <rect x="365" y="65" width="150" height="195" fill="none" stroke="#ef4444" stroke-width="1.8" stroke-dasharray="4,4"/>
  <rect x="365" y="47" width="145" height="18" fill="#991b1b"/>
  <text x="370" y="60" font-family="monospace" font-size="10" fill="#fecaca" font-weight="bold">ALARM: PROPPED_DOOR</text>

  <!-- Vignette & Scanlines -->
  <rect width="800" height="450" fill="url(#stairVignette)"/>
  <rect width="800" height="450" fill="url(#cctvScan3)"/>

  <!-- CCTV OSD Overlays -->
  <rect x="20" y="20" width="310" height="28" fill="#000000" opacity="0.75" rx="3"/>
  <circle cx="34" cy="34" r="5" fill="#ef4444">
    <animate attributeName="opacity" values="1;0.2;1" dur="1.8s" repeatCount="indefinite"/>
  </circle>
  <text x="46" y="38" font-family="monospace" font-size="12" fill="#2dd4bf" font-weight="bold">CAM-09 [REC] STAIRWELL_B_EXIT</text>

  <!-- Timestamp Top Right -->
  <rect x="530" y="20" width="250" height="28" fill="#000000" opacity="0.75" rx="3"/>
  <text x="542" y="38" font-family="monospace" font-size="12" fill="#f8fafc">2026-10-25 02:22:05.882 UTC</text>

  <!-- Telemetry Lower Left -->
  <text x="25" y="430" font-family="monospace" font-size="10" fill="#94a3b8">EVENT: REED_SWITCH_BYPASS | SENSOR: PIR-ACTIVE | LEVEL: BASEMENT -1</text>
  <text x="660" y="430" font-family="monospace" font-size="10" fill="#2dd4bf">SAFEFRAME VERIFIED</text>
</svg>`;

export const svgToDataUrl = (svgStr: string): string => {
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svgStr)}`;
};

export const sampleCase: IncidentCase = {
  id: 'case-sf-8492',
  caseNumber: 'SF-8492-SEC',
  title: 'Unauthorized Server Vault B Intrusion & Rack Manipulation',
  facility: 'Equinox Cyber-Tech North Campus — Secure Facility 03',
  leadInvestigator: 'Det. Sarah Vance, CISSP / GCFA',
  badgeNumber: 'SEC-89410',
  status: 'INVESTIGATING',
  severity: 'HIGH',
  incidentDate: '2026-10-25T02:14:18.000Z',
  description:
    'Security Operations Center (SOC) detected an anomalous perimeter loiter followed 6 minutes later by a physical door-contact alarm in Server Vault B. CCTV captures verify an unidentified individual in dark attire entering the restricted corridor and tampering with rack 04-B prior to exiting via Stairwell B emergency egress.',
  evidence: [
    {
      id: 'ev-01',
      name: 'CAM04_ServerVaultB_021418_frame.png',
      size: 428490,
      type: 'image/png',
      dataUrl: svgToDataUrl(cctvFrame1Svg),
      cameraSource: 'CAM-04: Server Vault B Corridor',
      capturedAt: '2026-10-25T02:14:18.422Z',
      uploadedAt: '2026-10-25T02:35:10.000Z',
      sha256: '9f83a216e5cdbc44129b0a98f77341829e1f5793d9a180429f448b1114d59a2b',
      recordedHash: '9f83a216e5cdbc44129b0a98f77341829e1f5793d9a180429f448b1114d59a2b',
      integrityStatus: 'verified',
      isSample: true,
      notes:
        'Key frame showing hooded subject in dark hoodie crouched adjacent to Server Rack 04B. Subject appears to be manipulating the lock mechanism with a slender metallic tool. Noticeable door tamper alert on badge reader frame.',
      analysis: {
        summary:
          'CCTV capture shows a single subject wearing dark, hooded clothing crouching in an active server rack corridor with the security latch on the left door visibly disengaged.',
        threatLevel: 'HIGH',
        threatJustification:
          'Direct physical access to restricted Tier-3 server infrastructure during non-business hours (02:14 UTC) with evidence of physical door bypass.',
        confirmedObservations: [
          'Subject is wearing dark monochrome apparel with hood raised completely over head.',
          'Subject is in a low-crouch posture positioned between the left corridor door and server rack bay 04.',
          'Left perimeter corridor door is physically ajar by approximately 15-20 degrees.',
          'Right server racks show active status LEDs (green, amber, red).',
          'A slender handheld metallic or composite object is gripped in the subject’s right hand.',
          'CCTV timestamp overlay indicates 2026-10-25 02:14:18.422 UTC.',
        ],
        uncertainConclusions: [
          'Uncertain whether the handheld item is a physical lock-picking rake, a console cable (RJ-45/USB bypass), or a pry wedge.',
          'Subject gender, age, and facial features cannot be determined due to low ambient lighting and deep hood shadow.',
          'Estimated subject height is approximately 175-185 cm based on server rack height reference (42U = 200 cm), but posture makes precision impossible.',
          'Unconfirmed whether the door was picked or if an electronic relay bypass tool was used.',
        ],
        entitiesDetected: [
          {
            label: 'Unidentified Subject (SUBJ_01)',
            location: 'Center-left corridor floor (X:330, Y:200)',
            confidence: '94%',
            details: 'Dark hoodie, dark trousers, dark footwear, carrying compact backpack.',
          },
          {
            label: 'Door Latch Bypass Point',
            location: 'Left frame door frame (X:110, Y:200)',
            confidence: '88%',
            details: 'Door contact disengaged, red indicator on lock body.',
          },
          {
            label: 'Handheld Tool',
            location: 'Subject right hand (X:350, Y:265)',
            confidence: '72%',
            details: 'Cylindrical or rod-like instrument approx 12-18cm length.',
          },
        ],
        lightingAndQualityAssessment:
          'Low ambient illumination (estimated < 5 lux), typical for standby night mode. Infrared sensor operational. Mild compression artifacts on subject edges.',
        anomalyHighlights: [
          'Access recorded without corresponding valid HID badge swipe in telemetry database.',
          'Presence in Tier-3 data zone outside scheduled maintenance window.',
          'Deliberate concealment of identity (hood and downward head angle).',
        ],
        investigativeActions: [
          'Audit switch port logs on Rack 04B for MAC address additions between 02:10 and 02:25 UTC.',
          'Correlate timestamp with exterior badge reader logs for North loading dock.',
          'Request physical forensic dusting for latent prints on Rack 04B lock bezel.',
        ],
        analyzedAt: '2026-10-25T02:40:00.000Z',
      },
    },
    {
      id: 'ev-02',
      name: 'CAM01_PerimeterGateN_020844_frame.png',
      size: 512930,
      type: 'image/png',
      dataUrl: svgToDataUrl(cctvFrame2Svg),
      cameraSource: 'CAM-01: Perimeter Gate North',
      capturedAt: '2026-10-25T02:08:44.119Z',
      uploadedAt: '2026-10-25T02:35:10.000Z',
      sha256: '3e41b9d72491a1820b001aef4c781190bcda42119028912ef093849120489110',
      recordedHash: '3e41b9d72491a1820b001aef4c781190bcda42119028912ef093849120489110',
      integrityStatus: 'verified',
      isSample: true,
      notes:
        'Exterior surveillance captured an unmarked commercial cargo van idling without headlights at the secondary perimeter fence 5 minutes and 34 seconds prior to the corridor breach.',
      analysis: {
        summary:
          'Surveillance captures a dark utility vehicle parked parallel to the north perimeter security fence with exterior headlights extinguished and brake lights illuminated.',
        threatLevel: 'MEDIUM',
        threatJustification:
          'Suspicious vehicular positioning directly adjacent to perimeter fence during off-hours, preceding the physical facility breach.',
        confirmedObservations: [
          'Dark-colored cargo-style van positioned parallel to northern perimeter fence.',
          'Headlamps are completely deactivated; vehicle is operating on parking/brake lights.',
          'Damp asphalt surface confirms recent precipitation in the perimeter area.',
          'Vehicle remained stationary in non-designated loading zone for over 8 minutes.',
        ],
        uncertainConclusions: [
          'Vehicle license plate characters are illegible due to spray accumulation, plate recess angle, and floodlight contrast.',
          'Make and model resembles a Ford Transit or Mercedes Sprinter high-roof van, but badging is not resolved.',
          'Number of vehicle occupants cannot be verified through tinted cabin glass.',
        ],
        entitiesDetected: [
          {
            label: 'Suspect Commercial Van',
            location: 'Perimeter fence roadway (X:330, Y:210)',
            confidence: '91%',
            details: 'Dark gray or black panel van, no external corporate logos visible.',
          },
          {
            label: 'Perimeter Fence Gate 3',
            location: 'Left background (X:100, Y:160)',
            confidence: '95%',
            details: 'Chain-link 3-meter security perimeter fence.',
          },
        ],
        lightingAndQualityAssessment:
          'High contrast backlighting from facility yard floodlights. Moisture glare on roadway. Infrared camera compensated for low light.',
        anomalyHighlights: [
          'Idling stationary in restricted security buffer zone without prior gate clearance.',
          'Operating in stealth configuration (headlights off while engine running).',
        ],
        investigativeActions: [
          'Request municipal traffic camera footage from County Road 14 intersection for 01:50 - 02:30 UTC.',
          'Check automated license plate recognition (ALPR) cameras at industrial park main gate.',
        ],
        analyzedAt: '2026-10-25T02:42:00.000Z',
      },
    },
    {
      id: 'ev-03',
      name: 'CAM09_StairwellBExit_022205_frame.png',
      size: 388120,
      type: 'image/png',
      dataUrl: svgToDataUrl(cctvFrame3Svg),
      cameraSource: 'CAM-09: Stairwell B Emergency Exit',
      capturedAt: '2026-10-25T02:22:05.882Z',
      uploadedAt: '2026-10-25T02:35:10.000Z',
      sha256: 'd482910fa8912ef8471b098192a74c1029487192837491028374829101928374',
      recordedHash: 'd482910fa8912ef8471b098192a74c1029487192837491028374829101928374',
      integrityStatus: 'verified',
      isSample: true,
      notes:
        'Fire stairwell B emergency exit door found propped open with an industrial wooden doorstop wedge. Magnetic reed switch was bypassed; local alarm beacon activated.',
      analysis: {
        summary:
          'Stairwell B exterior egress door is held open by a physical door wedge, triggering the local audible/visual emergency beacon visible in the upper frame.',
        threatLevel: 'HIGH',
        threatJustification:
          'Compromise of emergency egress pathway used as exfiltration corridor, leaving facility perimeter unsealed.',
        confirmedObservations: [
          'Steel emergency exit door is propped open at approximately 30 degrees.',
          'An orange high-density door wedge is positioned beneath the door leaf.',
          'The emergency strobe beacon at the upper wall is active and emitting red illumination.',
          'The door leaf emergency push-bar has been engaged from the interior side.',
        ],
        uncertainConclusions: [
          'Uncertain whether the wedge was pre-staged earlier by an insider or placed during exfiltration.',
          'Exit path leads toward the northeast perimeter fence line where the van was spotted.',
        ],
        entitiesDetected: [
          {
            label: 'Door Wedge / Prop Mechanism',
            location: 'Door base (X:405, Y:245)',
            confidence: '96%',
            details: 'Commercial high-visibility orange rubber/polymer door wedge.',
          },
          {
            label: 'Emergency Strobe Fixture',
            location: 'Upper stairwell wall (X:120, Y:60)',
            confidence: '98%',
            details: 'Flashing red strobe beacon actively triggered.',
          },
        ],
        lightingAndQualityAssessment:
          'Strong intermittent red chromatic flash from the alarm beacon. Concrete walls show high reflective scatter.',
        anomalyHighlights: [
          'Emergency exit door propped open; perimeter hermetic seal violated.',
          'Door wedge prevented auto-closer latch engagement.',
        ],
        investigativeActions: [
          'Collect the orange door wedge for forensic fingerprint and touch DNA analysis.',
          'Audit Stairwell B badge reader access history for previous 48 hours for pre-staging activity.',
        ],
        analyzedAt: '2026-10-25T02:44:00.000Z',
      },
    },
  ],
  timeline: [
    {
      id: 'tl-01',
      timestamp: '2026-10-25T02:08:44.119Z',
      title: 'Suspicious Vehicle Loiter Detected',
      description:
        'CAM-01 captures unmarked dark utility van idling along North Perimeter Fence with running lights only.',
      type: 'CCTV_DETECTION',
      evidenceId: 'ev-02',
      source: 'CAM-01 Perimeter Gate North',
      verified: true,
      severity: 'MEDIUM',
    },
    {
      id: 'tl-02',
      timestamp: '2026-10-25T02:11:02.000Z',
      title: 'Perimeter PIR Motion Alarm',
      description:
        'Zone 3 perimeter fence infrared beam triggered momentarily. Security guard dispatched to monitor monitor bank.',
      type: 'ALARM_TRIGGER',
      source: 'Building Automation / Bosch Security Panel',
      verified: true,
      severity: 'MEDIUM',
    },
    {
      id: 'tl-03',
      timestamp: '2026-10-25T02:14:18.422Z',
      title: 'Server Vault B Intrusion & Lock Tamper',
      description:
        'CAM-04 captures hooded individual crouching at Rack 04B with tool. No valid badge swipe registered on PAC controller.',
      type: 'CCTV_DETECTION',
      evidenceId: 'ev-01',
      source: 'CAM-04 Server Vault B Corridor',
      verified: true,
      severity: 'CRITICAL',
    },
    {
      id: 'tl-04',
      timestamp: '2026-10-25T02:16:40.000Z',
      title: 'Network Switch 04B Port Link Flap',
      description:
        'SIEM alert: Management interface gigabit-ethernet 1/0/24 disconnected and reconnected in promiscuous mode.',
      type: 'ALARM_TRIGGER',
      source: 'Cisco Catalyst 9300 Syslog',
      verified: true,
      severity: 'HIGH',
    },
    {
      id: 'tl-05',
      timestamp: '2026-10-25T02:22:05.882Z',
      title: 'Stairwell B Emergency Exit Propped Open',
      description:
        'CAM-09 captures emergency egress door wedged open; local tamper alarm sounds. Subject leaves facility view.',
      type: 'CCTV_DETECTION',
      evidenceId: 'ev-03',
      source: 'CAM-09 Stairwell B Emergency Exit',
      verified: true,
      severity: 'HIGH',
    },
    {
      id: 'tl-06',
      timestamp: '2026-10-25T02:24:12.000Z',
      title: 'Vehicle Departs Perimeter Roadway',
      description:
        'CAM-01 confirms the dark cargo van accelerated eastbound toward Highway 101 with headlights switched on.',
      type: 'CCTV_DETECTION',
      source: 'CAM-01 Perimeter Gate North',
      verified: true,
      severity: 'MEDIUM',
    },
    {
      id: 'tl-07',
      timestamp: '2026-10-25T02:35:10.000Z',
      title: 'Evidence Ingestion & SHA-256 Hashing',
      description:
        'Three CCTV frame captures extracted from Milestone NVR and ingested into SafeFrame AI evidence vault with SHA-256 signatures.',
      type: 'HASH_VERIFICATION',
      source: 'Lead Forensic Specialist',
      verified: true,
      severity: 'LOW',
    },
  ],
  synthesis: {
    executiveSummary:
      'A coordinated physical and cyber infiltration occurred at Facility 03 between 02:08 and 02:24 UTC on October 25, 2026. An unauthorized individual gained access to Server Vault B via a compromised corridor door and manipulated network hardware on Rack 04B before exfiltrating through a wedged emergency stairwell.',
    incidentClassification: 'Physical Security Infiltration & Hardware Interception',
    calculatedSeverity: 'HIGH',
    verifiedSequenceOfEvents: [
      '02:08 UTC: Suspicious vehicle idling at north perimeter without illumination.',
      '02:11 UTC: Zone 3 perimeter sensor trip.',
      '02:14 UTC: Visual detection of hooded subject inside Server Vault B corridor with door ajar.',
      '02:16 UTC: Network port flap alert on switch 04B indicating hardware tap insertion.',
      '02:22 UTC: Stairwell B emergency door propped open with wedge; subject departed.',
      '02:24 UTC: Van departed eastbound at high speed.',
    ],
    investigativeHypotheses: [
      'Probable hardware implant (drop-box / packet capture tap) attached to switch 04B port 24.',
      'Door wedge placement indicates either an inside accomplice pre-positioned the prop or the intruder carried it for guaranteed egress.',
      'Driver and physical intruder were separate individuals working in tandem.',
    ],
    criticalVulnerabilitiesExposed: [
      'Absence of magnetic interlocking mantrap on Server Vault B access.',
      'Blind spot in north perimeter fence line between CAM-01 and CAM-02.',
      'Delayed physical security response time (16 minutes between initial loiter and door alarm).',
    ],
    recommendedRemediation: [
      'Immediately isolate and physically inspect Switch 04B port 24 for unauthorized inline dongles.',
      'Deploy biometric multi-factor authentication (MFA) on all Tier-3 server room door strikes.',
      'Install infrared curtain sensors along the exterior stairwell emergency egress doors.',
      'Recalculate and re-verify all CCTV evidence hashes prior to evidentiary submission.',
    ],
    generatedAt: '2026-10-25T02:50:00.000Z',
  },
};
