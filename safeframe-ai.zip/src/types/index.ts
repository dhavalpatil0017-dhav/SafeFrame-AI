export type ThreatLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export type CaseStatus = 'OPEN' | 'INVESTIGATING' | 'ESCALATED' | 'RESOLVED';

export type IntegrityStatus = 'verified' | 'mismatch' | 'unverified';

export interface EntityDetected {
  label: string;
  location: string;
  confidence: string;
  details: string;
}

export interface AIAnalysisResult {
  summary: string;
  threatLevel: ThreatLevel;
  threatJustification: string;
  confirmedObservations: string[];
  uncertainConclusions: string[];
  entitiesDetected: EntityDetected[];
  lightingAndQualityAssessment: string;
  anomalyHighlights: string[];
  investigativeActions: string[];
  analyzedAt: string;
  modelUsed?: string;
}

export interface EvidenceFile {
  id: string;
  name: string;
  size: number;
  type: string;
  dataUrl: string; // Base64 or object URL
  cameraSource: string;
  capturedAt: string;
  uploadedAt: string;
  sha256: string;
  recordedHash?: string; // Baseline expected hash (e.g. from NVR manifest)
  integrityStatus: IntegrityStatus;
  notes: string;
  analysis?: AIAnalysisResult;
  isAnalyzing?: boolean;
  analysisError?: string;
  isSample?: boolean;
}

export interface TimelineEvent {
  id: string;
  timestamp: string; // ISO string
  title: string;
  description: string;
  type: 'CCTV_DETECTION' | 'BADGE_ACCESS' | 'ALARM_TRIGGER' | 'OFFICER_PATROL' | 'INVESTIGATOR_NOTE' | 'HASH_VERIFICATION';
  evidenceId?: string;
  source: string;
  verified: boolean;
  severity?: ThreatLevel;
}

export interface IncidentSynthesis {
  executiveSummary: string;
  incidentClassification: string;
  calculatedSeverity: ThreatLevel | string;
  verifiedSequenceOfEvents: string[];
  investigativeHypotheses: string[];
  criticalVulnerabilitiesExposed: string[];
  recommendedRemediation: string[];
  generatedAt: string;
}

export interface IncidentCase {
  id: string;
  caseNumber: string;
  title: string;
  facility: string;
  leadInvestigator: string;
  badgeNumber: string;
  status: CaseStatus;
  severity: ThreatLevel;
  incidentDate: string;
  description: string;
  evidence: EvidenceFile[];
  timeline: TimelineEvent[];
  synthesis?: IncidentSynthesis;
}
