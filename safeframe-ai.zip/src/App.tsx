/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { EvidenceVault } from './components/EvidenceVault';
import { AIIncidentAnalysis } from './components/AIIncidentAnalysis';
import { FileIntegrity } from './components/FileIntegrity';
import { IncidentTimeline } from './components/IncidentTimeline';
import { IncidentReport } from './components/IncidentReport';
import { NewCaseModal } from './components/NewCaseModal';
import { sampleCase } from './data/sampleCases';
import { EvidenceFile, IncidentCase, TimelineEvent, AIAnalysisResult } from './types';
import { optimizeImageForAnalysis, ensureRasterImage } from './utils/crypto';
import { CheckCircle2, AlertTriangle, Info, X } from 'lucide-react';

export default function App() {
  const [currentCase, setCurrentCase] = useState<IncidentCase>(() => {
    const saved = localStorage.getItem('safeframe_active_case');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return sampleCase;
      }
    }
    return sampleCase;
  });

  const [activeTab, setActiveTab] = useState<string>('vault');
  const [selectedEvidenceId, setSelectedEvidenceId] = useState<string | null>(
    currentCase.evidence[0]?.id || null
  );
  const [isSynthesizing, setIsSynthesizing] = useState<boolean>(false);
  const [isNewCaseModalOpen, setIsNewCaseModalOpen] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<{
    type: 'success' | 'alert' | 'info';
    text: string;
  } | null>(null);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('safeframe_active_case', JSON.stringify(currentCase));
  }, [currentCase]);

  const showToast = (text: string, type: 'success' | 'alert' | 'info' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 4500);
  };

  const handleResetSample = () => {
    setCurrentCase(sampleCase);
    setSelectedEvidenceId(sampleCase.evidence[0]?.id || null);
    showToast('Reset to default CCTV incident sample case (#SF-8492-SEC)', 'info');
  };

  const handleCreateNewCase = (newCase: IncidentCase) => {
    setCurrentCase(newCase);
    setSelectedEvidenceId(null);
    setActiveTab('vault');
    showToast(`New Case File ${newCase.caseNumber} initialized`, 'success');
  };

  const handleAddEvidence = (newFile: EvidenceFile) => {
    const updatedEvidence = [newFile, ...currentCase.evidence];
    const newTimelineEvent: TimelineEvent = {
      id: `tl-ev-${Date.now()}`,
      timestamp: newFile.capturedAt,
      title: `Evidence Frame Ingested: ${newFile.name}`,
      description: `CCTV frame from ${newFile.cameraSource} added to vault. SHA-256 verified (${newFile.sha256.substring(0, 12)}...).`,
      type: 'HASH_VERIFICATION',
      evidenceId: newFile.id,
      source: newFile.cameraSource,
      verified: true,
      severity: 'LOW',
    };

    setCurrentCase((prev) => ({
      ...prev,
      evidence: updatedEvidence,
      timeline: [newTimelineEvent, ...prev.timeline],
    }));

    setSelectedEvidenceId(newFile.id);
    showToast(`Evidence "${newFile.name}" ingested with verified SHA-256 digest`, 'success');
  };

  const handleDeleteEvidence = (id: string) => {
    setCurrentCase((prev) => ({
      ...prev,
      evidence: prev.evidence.filter((e) => e.id !== id),
      timeline: prev.timeline.filter((tl) => tl.evidenceId !== id),
    }));
    if (selectedEvidenceId === id) {
      setSelectedEvidenceId(currentCase.evidence.find((e) => e.id !== id)?.id || null);
    }
    showToast('Evidence file removed from active vault', 'info');
  };

  const handleUpdateEvidence = (id: string, updates: Partial<EvidenceFile>) => {
    setCurrentCase((prev) => ({
      ...prev,
      evidence: prev.evidence.map((e) => (e.id === id ? { ...e, ...updates } : e)),
    }));
  };

  const handleAnalyzeEvidence = async (file: EvidenceFile) => {
    // Set loading status
    handleUpdateEvidence(file.id, { isAnalyzing: true, analysisError: undefined });

    try {
      // Resize large images to max 1024px to ensure fast, sub-2s network transit
      const raster = await optimizeImageForAnalysis(file.dataUrl, 1024, 0.88);

      const response = await fetch('/api/analyze-evidence', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: raster.dataUrl,
          mimeType: raster.mimeType,
          fileName: file.name,
          cameraInfo: file.cameraSource,
          context: file.notes || currentCase.description,
        }),
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(result.error || 'Failed to complete AI CCTV examination.');
      }

      const analysisData: AIAnalysisResult = {
        ...result.data,
        modelUsed: result.modelUsed || 'gemini-3.1-flash-lite',
        analyzedAt: new Date().toISOString(),
      };

      handleUpdateEvidence(file.id, {
        isAnalyzing: false,
        analysis: analysisData,
      });

      // Add timeline observation event
      const timelineEvent: TimelineEvent = {
        id: `tl-ai-${Date.now()}`,
        timestamp: file.capturedAt,
        title: `AI Vision Analysis: ${file.name}`,
        description: `Gemini (${analysisData.modelUsed}) identified ${analysisData.confirmedObservations.length} confirmed facts and ${analysisData.uncertainConclusions.length} inferences. Threat evaluated as ${analysisData.threatLevel}.`,
        type: 'CCTV_DETECTION',
        evidenceId: file.id,
        source: 'SafeFrame AI Engine',
        verified: true,
        severity: analysisData.threatLevel,
      };

      setCurrentCase((prev) => ({
        ...prev,
        timeline: [timelineEvent, ...prev.timeline],
      }));

      setSelectedEvidenceId(file.id);
      showToast(`Analysis complete: ${analysisData.threatLevel} threat evaluated (${analysisData.modelUsed})`, 'success');
    } catch (error: any) {
      console.error('Error in handleAnalyzeEvidence:', error);
      handleUpdateEvidence(file.id, {
        isAnalyzing: false,
        analysisError: error.message || 'Error executing AI vision analysis.',
      });
      showToast(error.message || 'Failed to analyze CCTV frame', 'alert');
    }
  };

  const handleSynthesizeIncident = async () => {
    setIsSynthesizing(true);
    try {
      const response = await fetch('/api/synthesize-incident', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          caseId: currentCase.caseNumber,
          title: currentCase.title,
          evidenceList: currentCase.evidence.map((e) => ({
            fileName: e.name,
            camera: e.cameraSource,
            timestamp: e.capturedAt,
            analysisSummary: e.analysis?.summary,
            notes: e.notes,
          })),
          timelineEvents: currentCase.timeline,
        }),
      });

      const result = await response.json();
      if (!response.ok || !result.success) {
        throw new Error(result.error || 'Failed to synthesize incident narrative.');
      }

      setCurrentCase((prev) => ({
        ...prev,
        synthesis: {
          ...result.data,
          generatedAt: new Date().toISOString(),
        },
      }));

      showToast('Correlated incident synthesis generated successfully', 'success');
    } catch (err: any) {
      console.error('Error synthesizing incident:', err);
      showToast(err.message || 'Error generating incident synthesis', 'alert');
    } finally {
      setIsSynthesizing(false);
    }
  };

  const handleSimulateTamper = (id: string) => {
    const item = currentCase.evidence.find((e) => e.id === id);
    if (!item) return;

    // Simulate flipping a hash due to 1-byte file alteration
    const corruptedHash =
      'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855';

    handleUpdateEvidence(id, {
      sha256: corruptedHash,
      integrityStatus: 'mismatch',
    });

    showToast(
      `Tamper simulated on ${item.name}: SHA-256 hash avalanche flipped. Integrity status: MISMATCH`,
      'alert'
    );
  };

  const handleRestoreOriginal = (id: string) => {
    const item = currentCase.evidence.find((e) => e.id === id);
    if (!item) return;

    handleUpdateEvidence(id, {
      sha256: item.recordedHash || item.sha256,
      integrityStatus: 'verified',
    });

    showToast(`Hash restored for ${item.name}. Status: VERIFIED`, 'success');
  };

  const handleAddTimelineEvent = (event: TimelineEvent) => {
    setCurrentCase((prev) => ({
      ...prev,
      timeline: [event, ...prev.timeline],
    }));
    showToast(`Timeline event "${event.title}" recorded`, 'success');
  };

  const handleDeleteTimelineEvent = (id: string) => {
    setCurrentCase((prev) => ({
      ...prev,
      timeline: prev.timeline.filter((e) => e.id !== id),
    }));
    showToast('Timeline event removed', 'info');
  };

  const handleSelectForDeepAnalysis = (fileId: string) => {
    setSelectedEvidenceId(fileId);
    setActiveTab('analysis');
  };

  return (
    <div className="min-h-screen bg-[#070b14] text-slate-100 flex flex-col font-sans">
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 max-w-md animate-in fade-in slide-in-from-bottom-5 duration-200">
          <div
            className={`px-4 py-3 rounded-xl border shadow-2xl flex items-center gap-3 text-xs ${
              toastMessage.type === 'alert'
                ? 'bg-rose-950/95 border-rose-500/50 text-rose-200'
                : toastMessage.type === 'info'
                ? 'bg-slate-900/95 border-teal-500/50 text-teal-200'
                : 'bg-emerald-950/95 border-emerald-500/50 text-emerald-200'
            }`}
          >
            {toastMessage.type === 'alert' ? (
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
            ) : toastMessage.type === 'info' ? (
              <Info className="w-4 h-4 text-teal-400 shrink-0" />
            ) : (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            )}
            <span className="flex-1 font-medium leading-tight">{toastMessage.text}</span>
            <button
              onClick={() => setToastMessage(null)}
              className="text-slate-400 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Main Navigation Header */}
      <Header
        currentCase={currentCase}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onResetSample={handleResetSample}
        onOpenNewCaseModal={() => setIsNewCaseModalOpen(true)}
        onOpenReportModal={() => setActiveTab('report')}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6">
        {activeTab === 'vault' && (
          <EvidenceVault
            evidence={currentCase.evidence}
            onAddEvidence={handleAddEvidence}
            onDeleteEvidence={handleDeleteEvidence}
            onUpdateEvidence={handleUpdateEvidence}
            onAnalyzeEvidence={handleAnalyzeEvidence}
            onSelectForDeepAnalysis={handleSelectForDeepAnalysis}
          />
        )}

        {activeTab === 'analysis' && (
          <AIIncidentAnalysis
            currentCase={currentCase}
            selectedEvidenceId={selectedEvidenceId}
            onSelectEvidence={setSelectedEvidenceId}
            onAnalyzeEvidence={handleAnalyzeEvidence}
            onSynthesizeIncident={handleSynthesizeIncident}
            isSynthesizing={isSynthesizing}
          />
        )}

        {activeTab === 'integrity' && (
          <FileIntegrity
            evidence={currentCase.evidence}
            onUpdateEvidence={handleUpdateEvidence}
            onSimulateTamper={handleSimulateTamper}
            onRestoreOriginal={handleRestoreOriginal}
          />
        )}

        {activeTab === 'timeline' && (
          <IncidentTimeline
            timeline={currentCase.timeline}
            evidence={currentCase.evidence}
            onAddEvent={handleAddTimelineEvent}
            onDeleteEvent={handleDeleteTimelineEvent}
            onViewEvidence={handleSelectForDeepAnalysis}
          />
        )}

        {activeTab === 'report' && <IncidentReport currentCase={currentCase} />}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-[#060a12] py-4 text-xs text-slate-500 print:hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-400">SafeFrame AI</span>
            <span>•</span>
            <span>Preserve the Evidence. Understand the Incident.</span>
          </div>
          <div className="text-[11px] font-mono text-slate-400">
            SHA-256 WebCrypto Local Storage • Gemini 3.8 Flash Vision • Non-Repudiation Triage
          </div>
        </div>
      </footer>

      {/* New Case Modal */}
      <NewCaseModal
        isOpen={isNewCaseModalOpen}
        onClose={() => setIsNewCaseModalOpen(false)}
        onCreateCase={handleCreateNewCase}
      />
    </div>
  );
}
