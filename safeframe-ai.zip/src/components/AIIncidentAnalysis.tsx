import React, { useState } from 'react';
import {
  Sparkles,
  ShieldAlert,
  CheckCircle2,
  HelpCircle,
  AlertOctagon,
  Eye,
  Camera,
  Layers,
  ArrowRight,
  FileSearch,
  CheckSquare,
  Loader2,
  RefreshCw,
  Clock,
  Crosshair,
  Sliders,
  AlertTriangle,
} from 'lucide-react';
import { EvidenceFile, IncidentCase, AIAnalysisResult, IncidentSynthesis } from '../types';
import { formatCCTVTimestamp } from '../utils/crypto';

interface AIIncidentAnalysisProps {
  currentCase: IncidentCase;
  selectedEvidenceId: string | null;
  onSelectEvidence: (id: string) => void;
  onAnalyzeEvidence: (file: EvidenceFile) => void;
  onSynthesizeIncident: () => void;
  isSynthesizing: boolean;
}

export const AIIncidentAnalysis: React.FC<AIIncidentAnalysisProps> = ({
  currentCase,
  selectedEvidenceId,
  onSelectEvidence,
  onAnalyzeEvidence,
  onSynthesizeIncident,
  isSynthesizing,
}) => {
  const [activeTab, setActiveTab] = useState<'frame' | 'synthesis'>('frame');

  const selectedFile =
    currentCase.evidence.find((e) => e.id === selectedEvidenceId) ||
    currentCase.evidence[0] ||
    null;

  const analysis: AIAnalysisResult | undefined = selectedFile?.analysis;

  const severityBadge = (level: string) => {
    switch (level) {
      case 'CRITICAL':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/40';
      case 'HIGH':
        return 'bg-orange-500/20 text-orange-300 border-orange-500/40';
      case 'MEDIUM':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/40';
      default:
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40';
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900/60 p-4 rounded-xl border border-slate-800">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-teal-400" />
            AI CCTV Incident Analysis
          </h2>
          <p className="text-xs text-slate-400">
            Multimodal vision intelligence powered by Gemini 3.8 Flash. Strict evidentiary separation of facts vs inferences.
          </p>
        </div>

        {/* View mode toggle: Single Frame vs Multi-Evidence Synthesis */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab('frame')}
            className={`px-3 py-1.5 rounded-md font-medium transition ${
              activeTab === 'frame'
                ? 'bg-teal-500/20 text-teal-300 border border-teal-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Frame Inspector
          </button>
          <button
            onClick={() => setActiveTab('synthesis')}
            className={`px-3 py-1.5 rounded-md font-medium transition flex items-center gap-1.5 ${
              activeTab === 'synthesis'
                ? 'bg-teal-500/20 text-teal-300 border border-teal-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Case Synthesis</span>
          </button>
        </div>
      </div>

      {activeTab === 'frame' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Evidence Frame Selector & Visual Canvas (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            {/* Frame Selector Carousel / List */}
            <div className="bg-slate-900/70 p-3 rounded-xl border border-slate-800 space-y-2">
              <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                Select Evidence Frame to Inspect:
              </label>
              <div className="grid grid-cols-3 gap-2">
                {currentCase.evidence.map((item) => {
                  const isSelected = selectedFile?.id === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => onSelectEvidence(item.id)}
                      className={`relative aspect-video rounded-lg overflow-hidden border transition text-left ${
                        isSelected
                          ? 'border-teal-400 ring-2 ring-teal-500/20 shadow-md shadow-teal-950'
                          : 'border-slate-800 hover:border-slate-700 opacity-80 hover:opacity-100'
                      }`}
                    >
                      <img
                        src={item.dataUrl}
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent flex items-end p-1">
                        <span className="text-[9px] font-mono text-teal-300 truncate">
                          {item.cameraSource.split(':')[0]}
                        </span>
                      </div>
                      {item.analysis && (
                        <div className="absolute top-1 right-1 w-2 h-2 rounded-full bg-teal-400" />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Main Visual Display */}
            {selectedFile && (
              <div className="bg-slate-900/80 rounded-xl border border-slate-800 overflow-hidden shadow-lg">
                <div className="relative aspect-video bg-black flex items-center justify-center">
                  <img
                    src={selectedFile.dataUrl}
                    alt={selectedFile.name}
                    className="w-full h-full object-contain"
                  />
                  {/* CCTV Telemetry Overlay */}
                  <div className="absolute top-2 left-2 px-2 py-0.5 rounded bg-black/80 font-mono text-[10px] text-teal-300 border border-slate-700">
                    {selectedFile.cameraSource}
                  </div>
                  <div className="absolute top-2 right-2 px-2 py-0.5 rounded bg-black/80 font-mono text-[10px] text-slate-300 border border-slate-700">
                    {formatCCTVTimestamp(selectedFile.capturedAt)}
                  </div>
                </div>

                {/* Evidence Metadata bar */}
                <div className="p-3 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs">
                  <div>
                    <p className="font-semibold text-slate-200 truncate max-w-[200px]">
                      {selectedFile.name}
                    </p>
                    <p className="text-[10px] font-mono text-slate-400">
                      SHA-256: {selectedFile.sha256.substring(0, 16)}...
                    </p>
                  </div>
                  <button
                    onClick={() => onAnalyzeEvidence(selectedFile)}
                    disabled={selectedFile.isAnalyzing}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-950 font-semibold text-xs shadow-md transition disabled:opacity-50"
                  >
                    {selectedFile.isAnalyzing ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        <span>Analyzing with Gemini...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>{analysis ? 'Re-Analyze Frame' : 'Run AI Analysis'}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Right Column: Forensic Output (7 cols) */}
          {/* Right Column: Forensic Output (7 cols) */}
          <div className="lg:col-span-7 space-y-5">
            {selectedFile?.isAnalyzing ? (
              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-8 text-center flex flex-col items-center justify-center space-y-5 shadow-lg">
                <div className="relative">
                  <div className="w-16 h-16 rounded-full border-2 border-teal-500/20 border-t-teal-400 animate-spin" />
                  <Sparkles className="w-6 h-6 text-teal-400 absolute inset-0 m-auto animate-pulse" />
                </div>
                <div className="space-y-2 max-w-sm">
                  <h4 className="font-semibold text-white text-sm">
                    Multimodal Forensic Examination in Progress
                  </h4>
                  <p className="text-xs text-slate-400 font-mono leading-relaxed">
                    Analyzing pixel evidence with Gemini Vision • Partitioning confirmed visual facts from uncertain hypotheses...
                  </p>
                </div>
                {/* Fast optimization indicator */}
                <div className="flex flex-col gap-1.5 text-[11px] font-mono text-left w-full max-w-xs bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <div className="flex items-center gap-2 text-emerald-400">
                    <CheckSquare className="w-3.5 h-3.5" />
                    <span>Frame resized &amp; optimized (&le;1024px)</span>
                  </div>
                  <div className="flex items-center gap-2 text-teal-300 animate-pulse">
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Querying Gemini Multimodal Vision...</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-500">
                    <span className="w-3.5 h-3.5 flex items-center justify-center text-[10px]">○</span>
                    <span>Extracting entities &amp; observations</span>
                  </div>
                </div>
              </div>
            ) : selectedFile?.analysisError ? (
              <div className="bg-rose-950/30 border border-rose-500/40 rounded-xl p-6 text-rose-300 space-y-4 shadow-lg">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-2 font-bold text-sm text-rose-200">
                    <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
                    <span>Analysis Request Failed or Timed Out</span>
                  </div>
                  <button
                    onClick={() => selectedFile && onAnalyzeEvidence(selectedFile)}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/50 text-xs font-semibold rounded-lg text-rose-100 transition shadow-sm"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Retry Analysis</span>
                  </button>
                </div>
                <p className="text-xs text-rose-200/90 leading-relaxed font-mono bg-rose-950/40 p-3 rounded-lg border border-rose-900/50">
                  {selectedFile.analysisError}
                </p>
                <div className="text-[11px] text-rose-300/80 space-y-1">
                  <p>• Large images are automatically scaled down to prevent timeouts.</p>
                  <p>• If high demand or rate limits occurred on Google servers, clicking <strong>Retry Analysis</strong> will automatically try alternative active Gemini endpoints.</p>
                </div>
              </div>
            ) : analysis ? (
              <div className="space-y-5">
                {/* Threat Assessment & Executive Summary */}
                <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider">
                        Assessed Threat Severity:
                      </span>
                      <span
                        className={`px-2.5 py-0.5 rounded text-xs font-bold border ${severityBadge(
                          analysis.threatLevel
                        )}`}
                      >
                        {analysis.threatLevel}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-[10px] font-mono text-slate-400">
                      {analysis.modelUsed && (
                        <span className="px-2 py-0.5 rounded bg-teal-950 border border-teal-500/30 text-teal-300">
                          {analysis.modelUsed}
                        </span>
                      )}
                      <span>Evaluated: {formatCCTVTimestamp(analysis.analyzedAt)}</span>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-xs font-semibold text-teal-400 uppercase tracking-wider mb-1">
                      Forensic Overview
                    </h4>
                    <p className="text-xs text-slate-200 leading-relaxed">{analysis.summary}</p>
                    <p className="text-[11px] text-slate-400 mt-1 italic">
                      Reasoning: {analysis.threatJustification}
                    </p>
                  </div>
                </div>

                {/* THE CORE FORENSIC REQUIREMENT: CONFIRMED OBSERVATIONS VS UNCERTAIN CONCLUSIONS */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Confirmed Visual Observations */}
                  <div className="bg-emerald-950/20 border border-emerald-500/30 rounded-xl p-4 space-y-3">
                    <div className="flex items-center gap-2 text-emerald-300 font-bold text-xs uppercase tracking-wider border-b border-emerald-500/20 pb-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>Confirmed Observations</span>
                    </div>
                    <p className="text-[11px] text-emerald-400/80 font-mono">
                      [DIRECT VISIBLE PIXELS / VERIFIED FACTS]
                    </p>
                    <ul className="space-y-2 text-xs text-slate-200">
                      {analysis.confirmedObservations.map((obs, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <span className="text-emerald-400 font-mono font-bold text-xs mt-0.5">
                            •
                          </span>
                          <span className="leading-snug">{obs}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Uncertain Conclusions & Inferences */}
                  <div className="bg-amber-950/20 border border-amber-500/30 rounded-xl p-4 space-y-3">
                    <div className="flex items-center gap-2 text-amber-300 font-bold text-xs uppercase tracking-wider border-b border-amber-500/20 pb-2">
                      <HelpCircle className="w-4 h-4 text-amber-400 shrink-0" />
                      <span>Uncertain Conclusions</span>
                    </div>
                    <p className="text-[11px] text-amber-400/80 font-mono">
                      [INFERENCES / SPECULATIONS / HYPOTHESES]
                    </p>
                    <ul className="space-y-2 text-xs text-slate-200">
                      {analysis.uncertainConclusions.map((inf, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <span className="text-amber-400 font-mono font-bold text-xs mt-0.5">
                            ?
                          </span>
                          <span className="leading-snug">{inf}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Detected Entities & Spatial Annotations */}
                {analysis.entitiesDetected && analysis.entitiesDetected.length > 0 && (
                  <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-3">
                    <h4 className="text-xs font-semibold text-white flex items-center gap-2">
                      <Crosshair className="w-4 h-4 text-teal-400" />
                      Detected Entities & Spatial Objects
                    </h4>
                    <div className="overflow-x-auto">
                      <table className="w-full text-xs text-left">
                        <thead className="bg-slate-950 text-slate-400 font-mono text-[10px] border-b border-slate-800">
                          <tr>
                            <th className="py-2 px-3">Entity Label</th>
                            <th className="py-2 px-3">Frame Coordinates</th>
                            <th className="py-2 px-3">Confidence</th>
                            <th className="py-2 px-3">Description / Details</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800/60 font-mono">
                          {analysis.entitiesDetected.map((ent, i) => (
                            <tr key={i} className="hover:bg-slate-800/30">
                              <td className="py-2 px-3 font-semibold text-teal-300">
                                {ent.label}
                              </td>
                              <td className="py-2 px-3 text-slate-400 text-[11px]">
                                {ent.location}
                              </td>
                              <td className="py-2 px-3 text-emerald-400 font-semibold">
                                {ent.confidence}
                              </td>
                              <td className="py-2 px-3 font-sans text-slate-300 text-xs">
                                {ent.details}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* Sensor & Lighting Quality + Recommended Investigative Next Steps */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Quality & Sensor */}
                  <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 space-y-2">
                    <h5 className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                      <Sliders className="w-3.5 h-3.5 text-teal-400" />
                      Camera & Sensor Diagnostics
                    </h5>
                    <p className="text-xs text-slate-300 leading-relaxed font-mono">
                      {analysis.lightingAndQualityAssessment}
                    </p>
                  </div>

                  {/* Recommended Next Actions */}
                  <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 space-y-2">
                    <h5 className="text-xs font-semibold text-teal-300 flex items-center gap-1.5">
                      <CheckSquare className="w-3.5 h-3.5 text-teal-400" />
                      Recommended Investigative Actions
                    </h5>
                    <ul className="space-y-1.5 text-xs text-slate-300">
                      {analysis.investigativeActions.map((act, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="text-teal-400 text-[10px] mt-0.5">▶</span>
                          <span>{act}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-12 text-center space-y-4">
                <FileSearch className="w-12 h-12 text-slate-600 mx-auto" />
                <div className="max-w-md mx-auto space-y-1">
                  <h4 className="text-base font-semibold text-slate-200">
                    No Forensic Analysis Performed Yet
                  </h4>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Click "Run AI Analysis" to dispatch this CCTV frame to Gemini 3.8 Flash. The model
                    will rigorously itemize confirmed visual facts versus uncertain hypotheses.
                  </p>
                </div>
                <button
                  onClick={() => selectedFile && onAnalyzeEvidence(selectedFile)}
                  className="px-4 py-2 bg-teal-500 hover:bg-teal-400 text-slate-950 font-semibold text-xs rounded-lg shadow-sm transition"
                >
                  Analyze Selected Frame
                </button>
              </div>
            )}
          </div>
        </div>
      ) : (
        /* Multi-Evidence Incident Case Synthesis Tab */
        <div className="space-y-6">
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-6 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Layers className="w-5 h-5 text-teal-400" />
                  Correlated Multi-Source Incident Synthesis
                </h3>
                <p className="text-xs text-slate-400">
                  Synthesizes all {currentCase.evidence.length} evidence captures and{' '}
                  {currentCase.timeline.length} timeline events into a unified master forensic brief.
                </p>
              </div>
              <button
                onClick={onSynthesizeIncident}
                disabled={isSynthesizing}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-950 font-semibold text-xs shadow-md transition disabled:opacity-50"
              >
                {isSynthesizing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Synthesizing Full Case...</span>
                  </>
                ) : (
                  <>
                    <RefreshCw className="w-4 h-4" />
                    <span>
                      {currentCase.synthesis
                        ? 'Re-Synthesize Incident Narrative'
                        : 'Generate Synthesis Narrative'}
                    </span>
                  </>
                )}
              </button>
            </div>

            {currentCase.synthesis ? (
              <div className="space-y-6">
                {/* Executive Assessment Box */}
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2">
                    <span className="font-semibold text-sm text-teal-300">
                      {currentCase.synthesis.incidentClassification}
                    </span>
                    <span
                      className={`px-2.5 py-0.5 rounded text-xs font-bold border ${severityBadge(
                        currentCase.synthesis.calculatedSeverity
                      )}`}
                    >
                      {currentCase.synthesis.calculatedSeverity} SEVERITY
                    </span>
                  </div>
                  <p className="text-xs text-slate-200 leading-relaxed">
                    {currentCase.synthesis.executiveSummary}
                  </p>
                </div>

                {/* Verified Sequence vs Inferences */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div className="bg-emerald-950/20 border border-emerald-500/30 rounded-xl p-4 space-y-3">
                    <h4 className="text-xs font-bold text-emerald-300 uppercase tracking-wider flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      Verified Sequence of Events
                    </h4>
                    <ol className="space-y-2 text-xs text-slate-200">
                      {currentCase.synthesis.verifiedSequenceOfEvents.map((step, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <span className="font-mono text-emerald-400 font-bold text-xs mt-0.5">
                            {idx + 1}.
                          </span>
                          <span className="leading-snug">{step}</span>
                        </li>
                      ))}
                    </ol>
                  </div>

                  <div className="bg-amber-950/20 border border-amber-500/30 rounded-xl p-4 space-y-3">
                    <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
                      <HelpCircle className="w-4 h-4 text-amber-400" />
                      Investigative Hypotheses
                    </h4>
                    <ul className="space-y-2 text-xs text-slate-200">
                      {currentCase.synthesis.investigativeHypotheses.map((hyp, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <span className="text-amber-400 font-mono text-xs mt-0.5">?</span>
                          <span className="leading-snug">{hyp}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Vulnerabilities & Remediation */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div className="bg-rose-950/20 border border-rose-500/30 rounded-xl p-4 space-y-3">
                    <h4 className="text-xs font-bold text-rose-300 uppercase tracking-wider flex items-center gap-1.5">
                      <AlertOctagon className="w-4 h-4 text-rose-400" />
                      Physical & Cyber Vulnerabilities Exposed
                    </h4>
                    <ul className="space-y-2 text-xs text-slate-300">
                      {currentCase.synthesis.criticalVulnerabilitiesExposed.map((vuln, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <span className="text-rose-400 text-xs mt-0.5">⚠</span>
                          <span>{vuln}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-teal-950/20 border border-teal-500/30 rounded-xl p-4 space-y-3">
                    <h4 className="text-xs font-bold text-teal-300 uppercase tracking-wider flex items-center gap-1.5">
                      <CheckSquare className="w-4 h-4 text-teal-400" />
                      Recommended Security Remediation
                    </h4>
                    <ul className="space-y-2 text-xs text-slate-300">
                      {currentCase.synthesis.recommendedRemediation.map((rem, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <span className="text-teal-400 text-xs mt-0.5">✓</span>
                          <span>{rem}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-12 text-slate-400 space-y-3">
                <Layers className="w-10 h-10 text-slate-600 mx-auto" />
                <p className="text-sm font-medium text-slate-300">
                  Synthesize an integrated incident case across all evidence frames and timeline events.
                </p>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  Gemini will correlate CCTV detections from different camera angles, align timestamps,
                  and formulate verified sequences versus working hypotheses.
                </p>
                <button
                  onClick={onSynthesizeIncident}
                  className="px-4 py-2 bg-teal-500 hover:bg-teal-400 text-slate-950 font-semibold text-xs rounded-lg transition"
                >
                  Generate Incident Synthesis
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
