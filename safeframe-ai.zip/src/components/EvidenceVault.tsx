import React, { useState, useRef } from 'react';
import {
  Upload,
  FileImage,
  FileText,
  ShieldCheck,
  ShieldAlert,
  AlertTriangle,
  Sparkles,
  Eye,
  Trash2,
  Copy,
  Check,
  Search,
  Filter,
  Camera,
  Info,
  Maximize2,
  ExternalLink,
  Loader2,
  FileCheck,
} from 'lucide-react';
import { EvidenceFile } from '../types';
import { calculateFileHash, formatBytes, formatCCTVTimestamp } from '../utils/crypto';

interface EvidenceVaultProps {
  evidence: EvidenceFile[];
  onAddEvidence: (newFile: EvidenceFile) => void;
  onDeleteEvidence: (id: string) => void;
  onUpdateEvidence: (id: string, updates: Partial<EvidenceFile>) => void;
  onAnalyzeEvidence: (file: EvidenceFile) => void;
  onSelectForDeepAnalysis: (fileId: string) => void;
}

export const EvidenceVault: React.FC<EvidenceVaultProps> = ({
  evidence,
  onAddEvidence,
  onDeleteEvidence,
  onUpdateEvidence,
  onAnalyzeEvidence,
  onSelectForDeepAnalysis,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [cameraFilter, setCameraFilter] = useState('ALL');
  const [previewFile, setPreviewFile] = useState<EvidenceFile | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [copiedHashId, setCopiedHashId] = useState<string | null>(null);
  const [isProcessingUpload, setIsProcessingUpload] = useState(false);

  // Quick upload state
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewDataUrl, setPreviewDataUrl] = useState<string>('');
  const [cameraSource, setCameraSource] = useState('CAM-02: Facility Interior');
  const [customCamera, setCustomCamera] = useState('');
  const [recordedBaselineHash, setRecordedBaselineHash] = useState('');
  const [capturedAt, setCapturedAt] = useState(new Date().toISOString().slice(0, 19));
  const [notes, setNotes] = useState('');
  const [calculatedHash, setCalculatedHash] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const cameras = Array.from(new Set(evidence.map((e) => e.cameraSource)));

  const filteredEvidence = evidence.filter((item) => {
    const matchesSearch =
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.cameraSource.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.sha256.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCamera = cameraFilter === 'ALL' || item.cameraSource === cameraFilter;
    return matchesSearch && matchesCamera;
  });

  const handleCopyHash = (id: string, hash: string) => {
    navigator.clipboard.writeText(hash);
    setCopiedHashId(id);
    setTimeout(() => setCopiedHashId(null), 2000);
  };

  const handleFileDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      await processSelectedFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInputChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      await processSelectedFile(e.target.files[0]);
    }
  };

  const processSelectedFile = async (file: File) => {
    setIsProcessingUpload(true);
    try {
      setSelectedFile(file);
      const hash = await calculateFileHash(file);
      setCalculatedHash(hash);

      const reader = new FileReader();
      reader.onload = (event) => {
        setPreviewDataUrl(event.target?.result as string);
        setShowUploadModal(true);
        setIsProcessingUpload(false);
      };
      reader.readAsDataURL(file);
    } catch (err) {
      console.error('Error processing upload:', err);
      setIsProcessingUpload(false);
    }
  };

  const handleConfirmUpload = () => {
    if (!selectedFile) return;

    const finalCamera = customCamera.trim() || cameraSource;
    const finalRecorded = recordedBaselineHash.trim() || calculatedHash;
    const matches = finalRecorded.toLowerCase() === calculatedHash.toLowerCase();

    const newEvidence: EvidenceFile = {
      id: `ev-${Date.now()}`,
      name: selectedFile.name,
      size: selectedFile.size,
      type: selectedFile.type || 'application/octet-stream',
      dataUrl: previewDataUrl,
      cameraSource: finalCamera,
      capturedAt: new Date(capturedAt).toISOString(),
      uploadedAt: new Date().toISOString(),
      sha256: calculatedHash,
      recordedHash: finalRecorded,
      integrityStatus: matches ? 'verified' : 'mismatch',
      notes: notes.trim(),
    };

    onAddEvidence(newEvidence);
    setShowUploadModal(false);
    setSelectedFile(null);
    setPreviewDataUrl('');
    setCalculatedHash('');
    setRecordedBaselineHash('');
    setNotes('');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner / Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/60 p-4 rounded-xl border border-slate-800">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Camera className="w-5 h-5 text-teal-400" />
            CCTV Evidence Vault
          </h2>
          <p className="text-xs text-slate-400">
            Secure local repository for CCTV frame captures, video stills, and forensic sensor logs.
          </p>
        </div>

        {/* Search & Camera Filters */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Filter by filename, camera, or hash..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8 pr-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-teal-500 w-52 sm:w-64"
            />
          </div>

          <div className="relative flex items-center">
            <Filter className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            <select
              value={cameraFilter}
              onChange={(e) => setCameraFilter(e.target.value)}
              className="pl-8 pr-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-teal-500"
            >
              <option value="ALL">All Cameras ({evidence.length})</option>
              {cameras.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-teal-500 hover:bg-teal-400 text-slate-950 font-semibold rounded-lg text-xs transition shadow-sm"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Upload Evidence</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*,.txt,.log,.json"
            onChange={handleFileInputChange}
            className="hidden"
          />
        </div>
      </div>

      {/* Drag & Drop Ingestion Zone */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleFileDrop}
        className={`border-2 border-dashed rounded-xl p-6 text-center transition-all ${
          isDragging
            ? 'border-teal-400 bg-teal-500/10'
            : 'border-slate-800 hover:border-slate-700 bg-slate-950/40'
        }`}
      >
        <div className="max-w-md mx-auto flex flex-col items-center gap-2">
          {isProcessingUpload ? (
            <div className="flex flex-col items-center gap-2 text-teal-400 py-3">
              <Loader2 className="w-8 h-8 animate-spin" />
              <p className="text-xs font-mono">Computing SHA-256 cryptographic digest...</p>
            </div>
          ) : (
            <>
              <div className="w-10 h-10 rounded-full bg-slate-800/80 border border-slate-700 flex items-center justify-center text-teal-400">
                <Upload className="w-5 h-5" />
              </div>
              <p className="text-xs text-slate-300 font-medium">
                Drag and drop CCTV frame captures, video stills, or audit files here
              </p>
              <p className="text-[11px] text-slate-500">
                Supports PNG, JPEG, WEBP, SVG, and forensic text logs. Real SHA-256 computed instantly via WebCrypto.
              </p>
            </>
          )}
        </div>
      </div>

      {/* Evidence Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredEvidence.map((item) => {
          const isVerified = item.integrityStatus === 'verified';
          const isMismatch = item.integrityStatus === 'mismatch';

          return (
            <div
              key={item.id}
              className="bg-slate-900/80 border border-slate-800 hover:border-slate-700 rounded-xl overflow-hidden flex flex-col transition group shadow-md"
            >
              {/* Card Image Preview with CCTV Overlay */}
              <div className="relative aspect-video bg-black overflow-hidden flex items-center justify-center border-b border-slate-800/80">
                {item.dataUrl ? (
                  <img
                    src={item.dataUrl}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-[1.02] transition duration-300"
                  />
                ) : (
                  <div className="text-slate-600 flex flex-col items-center gap-2">
                    <FileText className="w-10 h-10" />
                    <span className="text-xs">Data Log</span>
                  </div>
                )}

                {/* CCTV Camera Badge Overlay */}
                <div className="absolute top-2 left-2 px-2 py-0.5 rounded bg-black/80 backdrop-blur border border-slate-700/80 text-[10px] font-mono text-teal-300 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping" />
                  <span className="truncate max-w-[170px]">{item.cameraSource}</span>
                </div>

                {/* Expand Preview Button */}
                <button
                  onClick={() => setPreviewFile(item)}
                  title="Expand CCTV Frame Preview"
                  className="absolute top-2 right-2 p-1.5 rounded bg-black/70 hover:bg-black text-slate-300 hover:text-white transition"
                >
                  <Maximize2 className="w-3.5 h-3.5" />
                </button>

                {/* Integrity Status Overlay Banner */}
                <div className="absolute bottom-2 left-2">
                  {isVerified && (
                    <span className="px-2 py-0.5 rounded bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-[10px] font-mono flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3 text-emerald-400" />
                      SHA-256 MATCHED
                    </span>
                  )}
                  {isMismatch && (
                    <span className="px-2 py-0.5 rounded bg-rose-950/80 border border-rose-500/40 text-rose-300 text-[10px] font-mono flex items-center gap-1">
                      <ShieldAlert className="w-3 h-3 text-rose-400" />
                      HASH MISMATCH
                    </span>
                  )}
                  {!isVerified && !isMismatch && (
                    <span className="px-2 py-0.5 rounded bg-amber-950/80 border border-amber-500/40 text-amber-300 text-[10px] font-mono flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3 text-amber-400" />
                      UNVERIFIED BASELINE
                    </span>
                  )}
                </div>

                {/* Timestamp lower right */}
                <div className="absolute bottom-2 right-2 px-1.5 py-0.5 rounded bg-black/80 text-[9px] font-mono text-slate-300">
                  {formatCCTVTimestamp(item.capturedAt)}
                </div>
              </div>

              {/* Card Details Body */}
              <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="font-semibold text-sm text-slate-100 truncate" title={item.name}>
                      {item.name}
                    </h3>
                    <span className="text-[11px] font-mono text-slate-400 whitespace-nowrap">
                      {formatBytes(item.size)}
                    </span>
                  </div>

                  <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                    {item.notes || 'No investigator annotations provided yet.'}
                  </p>
                </div>

                {/* SHA-256 Hash Display */}
                <div className="bg-slate-950/80 p-2 rounded-lg border border-slate-800 text-[11px]">
                  <div className="flex items-center justify-between text-slate-400 mb-1">
                    <span className="font-mono text-[10px] uppercase">SHA-256 Hash:</span>
                    <button
                      onClick={() => handleCopyHash(item.id, item.sha256)}
                      className="text-slate-400 hover:text-teal-300 flex items-center gap-1 transition"
                    >
                      {copiedHashId === item.id ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span className="text-[9px] text-emerald-400">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span className="text-[9px]">Copy</span>
                        </>
                      )}
                    </button>
                  </div>
                  <div className="font-mono text-slate-300 break-all select-all text-[10px] leading-tight">
                    {item.sha256}
                  </div>
                </div>

                {/* AI Analysis Summary Preview if available */}
                {item.analysis && (
                  <div className="bg-teal-950/30 border border-teal-500/20 rounded-lg p-2.5 text-xs">
                    <div className="flex items-center justify-between gap-1 mb-1">
                      <span className="flex items-center gap-1 text-[11px] font-semibold text-teal-300">
                        <Sparkles className="w-3 h-3 text-teal-400" />
                        AI Forensic Insight:
                      </span>
                      <span
                        className={`px-1.5 py-0.2 rounded text-[9px] font-bold ${
                          item.analysis.threatLevel === 'CRITICAL'
                            ? 'text-rose-400'
                            : item.analysis.threatLevel === 'HIGH'
                            ? 'text-orange-400'
                            : 'text-amber-400'
                        }`}
                      >
                        {item.analysis.threatLevel} THREAT
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300 line-clamp-2">
                      {item.analysis.summary}
                    </p>
                    <div className="mt-1 flex items-center gap-2 text-[10px] text-teal-400/80">
                      <span>{item.analysis.confirmedObservations.length} Confirmed Facts</span>
                      <span>•</span>
                      <span>{item.analysis.uncertainConclusions.length} Inferences</span>
                    </div>
                  </div>
                )}

                {/* AI Analysis Error Alert if failed */}
                {item.analysisError && (
                  <div className="bg-rose-950/40 border border-rose-500/30 rounded-lg p-2.5 text-xs text-rose-300 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-[11px] text-rose-200 flex items-center gap-1">
                        <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                        Analysis Issue:
                      </span>
                      <button
                        onClick={() => onAnalyzeEvidence(item)}
                        className="text-[10px] text-rose-200 underline font-medium hover:text-white"
                      >
                        Retry Now
                      </button>
                    </div>
                    <p className="text-[10px] text-rose-300/90 line-clamp-2 font-mono">
                      {item.analysisError}
                    </p>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    {/* Trigger AI Analysis */}
                    <button
                      onClick={() => onAnalyzeEvidence(item)}
                      disabled={item.isAnalyzing}
                      className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-teal-500/10 hover:bg-teal-500/20 border border-teal-500/30 text-teal-300 text-xs font-semibold transition disabled:opacity-50"
                    >
                      {item.isAnalyzing ? (
                        <>
                          <Loader2 className="w-3 h-3 animate-spin" />
                          <span>Analyzing...</span>
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-3 h-3 text-teal-400" />
                          <span>{item.analysis ? 'Re-Analyze AI' : 'Analyze Frame'}</span>
                        </>
                      )}
                    </button>

                    {item.analysis && (
                      <button
                        onClick={() => onSelectForDeepAnalysis(item.id)}
                        className="px-2 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition"
                        title="View Detailed Observations vs Inferences"
                      >
                        Deep View
                      </button>
                    )}
                  </div>

                  {/* Delete button */}
                  <button
                    onClick={() => onDeleteEvidence(item.id)}
                    title="Remove evidence"
                    className="p-1.5 text-slate-500 hover:text-rose-400 hover:bg-slate-800/80 rounded transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filteredEvidence.length === 0 && (
        <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-8 text-center text-slate-400">
          <p className="text-sm">No evidence files match the current search or camera filter.</p>
        </div>
      )}

      {/* Disclaimers & Non-repudiation note */}
      <div className="bg-slate-900/40 border border-slate-800/80 rounded-xl p-4 flex items-start gap-3 text-xs text-slate-400">
        <Info className="w-4 h-4 text-teal-400 shrink-0 mt-0.5" />
        <div>
          <p className="font-semibold text-slate-300">
            Forensic Integrity & Non-Repudiation Policy
          </p>
          <p className="mt-0.5 text-slate-400 leading-relaxed">
            All SHA-256 hashes are computed locally using Web Crypto SHA-256 upon ingestion.
            SafeFrame AI operates as a local-first investigative triage dashboard and does not claim
            automatic legal evidence verification or external statutory certification without an
            established chain-of-custody affidavit.
          </p>
        </div>
      </div>

      {/* Frame Full-screen Preview Modal */}
      {previewFile && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col shadow-2xl">
            {/* Modal Header */}
            <div className="px-5 py-3 border-b border-slate-800 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Camera className="w-4 h-4 text-teal-400" />
                  {previewFile.name}
                </h3>
                <p className="text-xs font-mono text-slate-400">
                  {previewFile.cameraSource} • {formatCCTVTimestamp(previewFile.capturedAt)}
                </p>
              </div>
              <button
                onClick={() => setPreviewFile(null)}
                className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition"
              >
                Close (Esc)
              </button>
            </div>

            {/* Modal Image Body with Scanline Effect */}
            <div className="relative bg-black flex-1 flex items-center justify-center overflow-auto p-2">
              <img
                src={previewFile.dataUrl}
                alt={previewFile.name}
                className="max-h-[65vh] w-auto object-contain rounded"
              />
            </div>

            {/* Modal Footer with Forensic Details */}
            <div className="px-5 py-3 border-t border-slate-800 bg-slate-950/80 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2 font-mono">
                <span className="text-slate-400">SHA-256:</span>
                <span className="text-teal-300 select-all">{previewFile.sha256}</span>
              </div>
              <button
                onClick={() => {
                  onSelectForDeepAnalysis(previewFile.id);
                  setPreviewFile(null);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-teal-500 hover:bg-teal-400 text-slate-950 font-semibold transition"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Open Forensic Analysis</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Upload Details Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <FileCheck className="w-5 h-5 text-teal-400" />
              Ingest CCTV Evidence File
            </h3>

            {/* File metadata summary */}
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-xs space-y-1.5">
              <div className="flex justify-between">
                <span className="text-slate-400">Filename:</span>
                <span className="text-slate-200 font-mono font-medium truncate max-w-[240px]">
                  {selectedFile?.name}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">File Size:</span>
                <span className="text-slate-200 font-mono">
                  {selectedFile && formatBytes(selectedFile.size)}
                </span>
              </div>
              <div className="flex flex-col gap-0.5">
                <span className="text-slate-400">Calculated SHA-256 Hash:</span>
                <span className="text-teal-300 font-mono text-[10px] break-all">
                  {calculatedHash}
                </span>
              </div>
            </div>

            {/* Camera Source Selector */}
            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-300">CCTV Camera / Source</label>
              <select
                value={cameraSource}
                onChange={(e) => setCameraSource(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-teal-500"
              >
                <option value="CAM-01: Perimeter Gate North">CAM-01: Perimeter Gate North</option>
                <option value="CAM-02: Facility Main Entrance">CAM-02: Facility Main Entrance</option>
                <option value="CAM-03: Security Operations Center">CAM-03: Security Operations Center</option>
                <option value="CAM-04: Server Vault B Corridor">CAM-04: Server Vault B Corridor</option>
                <option value="CAM-07: Loading Bay 2">CAM-07: Loading Bay 2</option>
                <option value="CAM-09: Stairwell B Emergency Exit">CAM-09: Stairwell B Emergency Exit</option>
                <option value="CUSTOM">Custom Camera Source...</option>
              </select>
              {cameraSource === 'CUSTOM' && (
                <input
                  type="text"
                  placeholder="e.g. CAM-12: Roof HVAC Access"
                  value={customCamera}
                  onChange={(e) => setCustomCamera(e.target.value)}
                  className="w-full mt-1 px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-teal-500"
                />
              )}
            </div>

            {/* Baseline Hash (For Integrity Matching) */}
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label className="text-xs font-medium text-slate-300">
                  Recorded Baseline Hash (From NVR Manifest)
                </label>
                <button
                  type="button"
                  onClick={() => setRecordedBaselineHash(calculatedHash)}
                  className="text-[10px] text-teal-400 hover:underline"
                >
                  Set as Initial Baseline
                </button>
              </div>
              <input
                type="text"
                placeholder="Paste expected SHA-256 hash or leave empty to use calculated hash"
                value={recordedBaselineHash}
                onChange={(e) => setRecordedBaselineHash(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs font-mono text-slate-200 placeholder-slate-500 focus:outline-none focus:border-teal-500"
              />
            </div>

            {/* Captured Timestamp */}
            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-300">CCTV Verified Timestamp</label>
              <input
                type="datetime-local"
                value={capturedAt}
                onChange={(e) => setCapturedAt(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-teal-500"
              />
            </div>

            {/* Notes */}
            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-300">Investigator Notes</label>
              <textarea
                rows={2}
                placeholder="Initial triage remarks, suspect observations, or extraction reason..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-teal-500"
              />
            </div>

            {/* Buttons */}
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowUploadModal(false)}
                className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmUpload}
                className="px-4 py-1.5 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-950 text-xs font-semibold shadow-sm transition"
              >
                Ingest into Vault
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
