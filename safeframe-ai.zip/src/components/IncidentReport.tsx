import React from 'react';
import {
  FileText,
  Download,
  Printer,
  ShieldCheck,
  CheckCircle2,
  HelpCircle,
  Clock,
  Layers,
  FileCode,
  Share2,
} from 'lucide-react';
import { IncidentCase } from '../types';
import { formatBytes, formatCCTVTimestamp } from '../utils/crypto';

interface IncidentReportProps {
  currentCase: IncidentCase;
}

export const IncidentReport: React.FC<IncidentReportProps> = ({ currentCase }) => {
  const verifiedHashes = currentCase.evidence.filter(
    (e) => e.integrityStatus === 'verified'
  ).length;

  const handlePrint = () => {
    window.print();
  };

  const generateMarkdownReport = (): string => {
    const lines: string[] = [];
    lines.push(`# SafeFrame AI — Forensic CCTV Incident Report`);
    lines.push(`**Case Number:** ${currentCase.caseNumber}`);
    lines.push(`**Incident Title:** ${currentCase.title}`);
    lines.push(`**Facility:** ${currentCase.facility}`);
    lines.push(`**Lead Investigator:** ${currentCase.leadInvestigator} (Badge: ${currentCase.badgeNumber})`);
    lines.push(`**Date & Time:** ${formatCCTVTimestamp(currentCase.incidentDate)}`);
    lines.push(`**Severity Level:** ${currentCase.severity} | **Status:** ${currentCase.status}`);
    lines.push(``);
    lines.push(`---`);
    lines.push(``);
    lines.push(`## 1. Executive Incident Summary`);
    lines.push(currentCase.description);
    if (currentCase.synthesis) {
      lines.push(``);
      lines.push(`### Correlated Case Assessment`);
      lines.push(currentCase.synthesis.executiveSummary);
    }
    lines.push(``);
    lines.push(`## 2. Evidence Vault Manifest (Cryptographic Ledger)`);
    lines.push(`| Filename | Source Camera | Size | Captured Timestamp | SHA-256 Digest | Status |`);
    lines.push(`|---|---|---|---|---|---|`);
    currentCase.evidence.forEach((e) => {
      lines.push(
        `| ${e.name} | ${e.cameraSource} | ${formatBytes(e.size)} | ${formatCCTVTimestamp(
          e.capturedAt
        )} | \`${e.sha256}\` | ${e.integrityStatus.toUpperCase()} |`
      );
    });
    lines.push(``);
    lines.push(`## 3. Multimodal CCTV AI Forensic Analysis`);
    currentCase.evidence.forEach((e, idx) => {
      if (e.analysis) {
        lines.push(`### Evidence Item ${idx + 1}: ${e.name} (${e.cameraSource})`);
        lines.push(`**Threat Evaluation:** ${e.analysis.threatLevel} — ${e.analysis.threatJustification}`);
        lines.push(`**Frame Summary:** ${e.analysis.summary}`);
        lines.push(``);
        lines.push(`#### Confirmed Visual Observations (Direct Pixel Evidence):`);
        e.analysis.confirmedObservations.forEach((obs) => lines.push(`- [VERIFIED] ${obs}`));
        lines.push(``);
        lines.push(`#### Uncertain Conclusions & Inferences (Hypotheses):`);
        e.analysis.uncertainConclusions.forEach((inf) => lines.push(`- [INFERENCE] ${inf}`));
        lines.push(``);
        if (e.analysis.entitiesDetected && e.analysis.entitiesDetected.length > 0) {
          lines.push(`#### Detected Entities:`);
          e.analysis.entitiesDetected.forEach((ent) =>
            lines.push(`- ${ent.label} (${ent.location}): ${ent.confidence} confidence. ${ent.details}`)
          );
          lines.push(``);
        }
      }
    });
    lines.push(``);
    lines.push(`## 4. Chronological Sequence of Events (Timeline)`);
    const sorted = [...currentCase.timeline].sort(
      (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );
    sorted.forEach((item) => {
      lines.push(
        `- **${formatCCTVTimestamp(item.timestamp)}** [${item.type}] **${item.title}**: ${
          item.description
        } (Source: ${item.source})`
      );
    });
    lines.push(``);
    lines.push(`## 5. Attestation & Chain of Custody`);
    lines.push(`All digital files ingested into SafeFrame AI have been hashed with SHA-256.`);
    lines.push(`Generated: ${new Date().toISOString()} via SafeFrame AI Forensic Engine.`);
    return lines.join('\n');
  };

  const handleDownloadMarkdown = () => {
    const md = generateMarkdownReport();
    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `SafeFrame_Report_${currentCase.caseNumber}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadJson = () => {
    const jsonStr = JSON.stringify(currentCase, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `SafeFrame_CaseBundle_${currentCase.caseNumber}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900/60 p-4 rounded-xl border border-slate-800 print:hidden">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-teal-400" />
            Formal Incident Report Dossier
          </h2>
          <p className="text-xs text-slate-400">
            Export-ready forensic incident summary with cryptographic evidence manifest, AI observations, and timeline.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleDownloadMarkdown}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-teal-300 border border-slate-700 text-xs font-semibold transition"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download .MD</span>
          </button>

          <button
            onClick={handleDownloadJson}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs font-semibold transition"
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>JSON Bundle</span>
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs shadow-md transition"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print / PDF</span>
          </button>
        </div>
      </div>

      {/* Printable Report Document Card */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-8 shadow-xl max-w-5xl mx-auto print:bg-white print:text-black print:border-none print:shadow-none print:p-0">
        {/* Document Header */}
        <div className="border-b border-slate-800 print:border-slate-300 pb-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-black tracking-tight text-white print:text-black">
                  SafeFrame <span className="text-teal-400 print:text-teal-700">AI</span>
                </span>
                <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-950 print:bg-slate-100 text-teal-300 print:text-teal-700 border border-teal-500/30">
                  SECURITY INCIDENT DOSSIER
                </span>
              </div>
              <p className="text-xs text-slate-400 print:text-slate-600 font-mono mt-1">
                Ref ID: {currentCase.caseNumber} • Generated on{' '}
                {new Date().toISOString().replace('T', ' ').substring(0, 19)} UTC
              </p>
            </div>

            <div className="text-right">
              <span className="inline-block px-3 py-1 rounded text-xs font-mono font-bold bg-teal-500/10 text-teal-300 print:text-teal-800 border border-teal-500/30">
                STATUS: {currentCase.status}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono pt-4 border-t border-slate-800/60 print:border-slate-200">
            <div>
              <span className="text-slate-400 print:text-slate-500 block">Incident Date/Time</span>
              <span className="text-slate-200 print:text-black font-semibold">
                {formatCCTVTimestamp(currentCase.incidentDate)}
              </span>
            </div>
            <div>
              <span className="text-slate-400 print:text-slate-500 block">Facility Location</span>
              <span className="text-slate-200 print:text-black font-semibold">
                {currentCase.facility}
              </span>
            </div>
            <div>
              <span className="text-slate-400 print:text-slate-500 block">Lead Investigator</span>
              <span className="text-slate-200 print:text-black font-semibold">
                {currentCase.leadInvestigator}
              </span>
            </div>
            <div>
              <span className="text-slate-400 print:text-slate-500 block">Assessed Severity</span>
              <span className="text-teal-300 print:text-teal-800 font-bold">
                {currentCase.severity}
              </span>
            </div>
          </div>
        </div>

        {/* Section 1: Executive Case Narrative */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-teal-400 print:text-teal-800 uppercase tracking-wider font-mono">
            1. Executive Case Summary
          </h3>
          <p className="text-xs sm:text-sm text-slate-200 print:text-slate-800 leading-relaxed">
            {currentCase.description}
          </p>

          {currentCase.synthesis && (
            <div className="mt-3 p-3.5 bg-slate-950 print:bg-slate-50 rounded-xl border border-slate-800 print:border-slate-200 text-xs text-slate-300 print:text-slate-700 leading-relaxed">
              <strong className="text-teal-300 print:text-teal-800 block mb-1">
                Correlated Synthesis Brief:
              </strong>
              {currentCase.synthesis.executiveSummary}
            </div>
          )}
        </div>

        {/* Section 2: Cryptographic Evidence Manifest */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-teal-400 print:text-teal-800 uppercase tracking-wider font-mono">
              2. Evidence Vault Manifest & Cryptographic Ledger
            </h3>
            <span className="text-[11px] font-mono text-emerald-400 print:text-emerald-700">
              {verifiedHashes}/{currentCase.evidence.length} Hashes Cryptographically Verified
            </span>
          </div>

          <div className="overflow-x-auto border border-slate-800 print:border-slate-300 rounded-xl">
            <table className="w-full text-xs text-left font-mono">
              <thead className="bg-slate-950 print:bg-slate-100 text-slate-400 print:text-slate-600 text-[10px] uppercase border-b border-slate-800 print:border-slate-300">
                <tr>
                  <th className="py-2.5 px-3">Filename</th>
                  <th className="py-2.5 px-3">Source Camera</th>
                  <th className="py-2.5 px-3">Size</th>
                  <th className="py-2.5 px-3">Captured Timestamp</th>
                  <th className="py-2.5 px-3">SHA-256 Digest</th>
                  <th className="py-2.5 px-3 text-center">Integrity</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 print:divide-slate-200 text-[11px]">
                {currentCase.evidence.map((item) => (
                  <tr key={item.id}>
                    <td className="py-2 px-3 font-semibold text-slate-200 print:text-black">
                      {item.name}
                    </td>
                    <td className="py-2 px-3 text-slate-400 print:text-slate-700">
                      {item.cameraSource}
                    </td>
                    <td className="py-2 px-3 text-slate-400 print:text-slate-700">
                      {formatBytes(item.size)}
                    </td>
                    <td className="py-2 px-3 text-slate-300 print:text-slate-800">
                      {formatCCTVTimestamp(item.capturedAt)}
                    </td>
                    <td className="py-2 px-3 text-[10px] text-teal-300 print:text-teal-900 break-all select-all">
                      {item.sha256}
                    </td>
                    <td className="py-2 px-3 text-center">
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-emerald-500/10 text-emerald-400 print:text-emerald-800 border border-emerald-500/30">
                        {item.integrityStatus.toUpperCase()}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Section 3: AI CCTV Incident Analysis Breakdown */}
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-teal-400 print:text-teal-800 uppercase tracking-wider font-mono">
            3. Multimodal CCTV AI Forensic Analysis
          </h3>
          <p className="text-xs text-slate-400 print:text-slate-600 italic">
            Automated visual feature extraction strictly partitioning confirmed pixel facts from uncertain hypotheses.
          </p>

          <div className="space-y-4">
            {currentCase.evidence.map((item, idx) => {
              if (!item.analysis) return null;
              return (
                <div
                  key={item.id}
                  className="bg-slate-950 print:bg-slate-50 border border-slate-800 print:border-slate-300 rounded-xl p-4 space-y-3"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 print:border-slate-200 pb-2">
                    <span className="font-bold text-xs text-slate-100 print:text-black font-mono">
                      Capture {idx + 1}: {item.name} ({item.cameraSource})
                    </span>
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-teal-500/10 text-teal-300 print:text-teal-800 border border-teal-500/30">
                      THREAT: {item.analysis.threatLevel}
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 print:text-slate-700">
                    {item.analysis.summary}
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
                    {/* Confirmed observations */}
                    <div className="p-3 rounded-lg bg-emerald-950/20 print:bg-emerald-50 border border-emerald-500/20 print:border-emerald-200">
                      <h4 className="text-[11px] font-bold text-emerald-300 print:text-emerald-800 flex items-center gap-1.5 uppercase font-mono mb-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        Confirmed Visual Observations:
                      </h4>
                      <ul className="space-y-1 text-xs text-slate-200 print:text-slate-800">
                        {item.analysis.confirmedObservations.map((obs, i) => (
                          <li key={i} className="flex items-start gap-1.5">
                            <span className="text-emerald-400 font-bold">•</span>
                            <span>{obs}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Uncertain conclusions */}
                    <div className="p-3 rounded-lg bg-amber-950/20 print:bg-amber-50 border border-amber-500/20 print:border-amber-200">
                      <h4 className="text-[11px] font-bold text-amber-300 print:text-amber-800 flex items-center gap-1.5 uppercase font-mono mb-2">
                        <HelpCircle className="w-3.5 h-3.5 text-amber-400" />
                        Uncertain Conclusions & Inferences:
                      </h4>
                      <ul className="space-y-1 text-xs text-slate-200 print:text-slate-800">
                        {item.analysis.uncertainConclusions.map((inf, i) => (
                          <li key={i} className="flex items-start gap-1.5">
                            <span className="text-amber-400 font-bold">?</span>
                            <span>{inf}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Section 4: Chronological Sequence of Events */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-teal-400 print:text-teal-800 uppercase tracking-wider font-mono">
            4. Chronological Timeline of Events
          </h3>

          <div className="space-y-2 border-l-2 border-slate-800 print:border-slate-300 pl-4">
            {[...currentCase.timeline]
              .sort(
                (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
              )
              .map((ev) => (
                <div key={ev.id} className="text-xs">
                  <div className="flex items-center gap-2 font-mono">
                    <span className="font-bold text-teal-300 print:text-teal-800">
                      {formatCCTVTimestamp(ev.timestamp)}
                    </span>
                    <span className="text-slate-500 print:text-slate-400">•</span>
                    <span className="font-semibold text-slate-200 print:text-black">
                      {ev.title}
                    </span>
                    <span className="text-[10px] text-slate-400">({ev.source})</span>
                  </div>
                  <p className="text-slate-400 print:text-slate-700 mt-0.5 ml-2">
                    {ev.description}
                  </p>
                </div>
              ))}
          </div>
        </div>

        {/* Section 5: Attestation & Signature */}
        <div className="pt-6 border-t border-slate-800 print:border-slate-300 space-y-4">
          <h3 className="text-sm font-bold text-teal-400 print:text-teal-800 uppercase tracking-wider font-mono">
            5. Evidentiary Attestation & Sign-off
          </h3>
          <p className="text-xs text-slate-400 print:text-slate-600 leading-relaxed">
            I hereby certify that the evidence files enumerated above were preserved in SafeFrame AI
            with calculated SHA-256 digests. AI-assisted analysis was utilized for triage assistance
            under strict human oversight.
          </p>

          <div className="grid grid-cols-2 gap-8 pt-4">
            <div className="border-t border-slate-700 print:border-slate-400 pt-2 text-xs">
              <span className="text-slate-400 print:text-slate-600 block">Lead Investigator Signature:</span>
              <span className="font-semibold text-slate-200 print:text-black mt-1 block">
                {currentCase.leadInvestigator}
              </span>
            </div>
            <div className="border-t border-slate-700 print:border-slate-400 pt-2 text-xs">
              <span className="text-slate-400 print:text-slate-600 block">Date of Certification:</span>
              <span className="font-semibold text-slate-200 print:text-black mt-1 block">
                {new Date().toISOString().substring(0, 10)}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
