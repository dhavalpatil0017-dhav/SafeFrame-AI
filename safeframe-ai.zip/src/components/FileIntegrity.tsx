import React, { useState } from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  AlertTriangle,
  FileCheck2,
  Copy,
  Check,
  RefreshCw,
  Download,
  Terminal,
  Sliders,
  CheckCircle,
  XCircle,
  Hash,
  FileCode,
} from 'lucide-react';
import { EvidenceFile } from '../types';
import { calculateStringHash, calculateFileHash, compareHashes, formatBytes } from '../utils/crypto';

interface FileIntegrityProps {
  evidence: EvidenceFile[];
  onUpdateEvidence: (id: string, updates: Partial<EvidenceFile>) => void;
  onSimulateTamper: (id: string) => void;
  onRestoreOriginal: (id: string) => void;
}

export const FileIntegrity: React.FC<FileIntegrityProps> = ({
  evidence,
  onUpdateEvidence,
  onSimulateTamper,
  onRestoreOriginal,
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editHashInput, setEditHashInput] = useState<string>('');

  // Standalone Verification Tool state
  const [toolText, setToolText] = useState<string>('');
  const [toolCalculatedHash, setToolCalculatedHash] = useState<string>('');
  const [compareHashInput, setCompareHashInput] = useState<string>('');
  const [isToolComparing, setIsToolComparing] = useState<boolean>(false);

  const verifiedCount = evidence.filter((e) => e.integrityStatus === 'verified').length;
  const mismatchCount = evidence.filter((e) => e.integrityStatus === 'mismatch').length;
  const unverifiedCount = evidence.filter((e) => e.integrityStatus === 'unverified').length;

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleStartEditBaseline = (item: EvidenceFile) => {
    setEditingId(item.id);
    setEditHashInput(item.recordedHash || item.sha256);
  };

  const handleSaveBaseline = (id: string, currentSha: string) => {
    const trimmed = editHashInput.trim();
    const isMatch = compareHashes(trimmed, currentSha);
    onUpdateEvidence(id, {
      recordedHash: trimmed,
      integrityStatus: isMatch ? 'verified' : 'mismatch',
    });
    setEditingId(null);
  };

  const handleCalculateToolText = async (val: string) => {
    setToolText(val);
    if (!val) {
      setToolCalculatedHash('');
      return;
    }
    const hash = await calculateStringHash(val);
    setToolCalculatedHash(hash);
  };

  const handleToolFileDrop = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const hash = await calculateFileHash(file);
      setToolCalculatedHash(hash);
      setToolText(`[File Ingested: ${file.name} (${formatBytes(file.size)})]`);
    }
  };

  const handleDownloadManifest = () => {
    const manifestLines = evidence.map((e) => `${e.sha256}  ${e.name}`);
    const blob = new Blob([manifestLines.join('\n')], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `SafeFrame_Manifest_${Date.now()}.sha256`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const toolMatch =
    toolCalculatedHash &&
    compareHashInput.trim() &&
    toolCalculatedHash.toLowerCase() === compareHashInput.trim().toLowerCase();

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900/60 p-4 rounded-xl border border-slate-800">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-teal-400" />
            File Integrity & Cryptographic Hashes
          </h2>
          <p className="text-xs text-slate-400">
            SHA-256 cryptographic non-repudiation verifying that CCTV files remain bit-exact and unaltered.
          </p>
        </div>

        <button
          onClick={handleDownloadManifest}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-teal-300 border border-slate-700 text-xs font-semibold transition"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export .sha256 Manifest</span>
        </button>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-900/80 border border-slate-800 p-4 rounded-xl flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <div className="text-2xl font-bold font-mono text-white">{verifiedCount}</div>
            <div className="text-xs text-emerald-400 font-medium">Verified Matching Hashes</div>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-4 rounded-xl flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-400">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div>
            <div className="text-2xl font-bold font-mono text-white">{mismatchCount}</div>
            <div className="text-xs text-rose-400 font-medium">Integrity Mismatches</div>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-4 rounded-xl flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-400">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <div className="text-2xl font-bold font-mono text-white">{unverifiedCount}</div>
            <div className="text-xs text-amber-400 font-medium">Unverified Baselines</div>
          </div>
        </div>
      </div>

      {/* Evidence Integrity Ledger Table */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl overflow-hidden shadow-md">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <FileCode className="w-4 h-4 text-teal-400" />
            Active Evidence Integrity Ledger
          </h3>
          <span className="text-xs text-slate-400 font-mono">
            Algorithm: SHA-256 (FIPS 180-4)
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-950 text-slate-400 font-mono text-[10px] uppercase border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Evidence File</th>
                <th className="py-3 px-4">Calculated SHA-256 (Current)</th>
                <th className="py-3 px-4">Recorded Baseline Hash</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Tamper Test / Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 font-mono">
              {evidence.map((item) => {
                const isMatch = item.integrityStatus === 'verified';
                const isMismatch = item.integrityStatus === 'mismatch';

                return (
                  <tr key={item.id} className="hover:bg-slate-800/30 transition">
                    {/* Filename & Camera */}
                    <td className="py-3 px-4">
                      <div className="font-sans font-semibold text-slate-200 truncate max-w-[180px]">
                        {item.name}
                      </div>
                      <div className="text-[10px] text-slate-400 truncate max-w-[180px]">
                        {item.cameraSource}
                      </div>
                    </td>

                    {/* Calculated Hash */}
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`break-all text-[11px] select-all ${
                            isMatch
                              ? 'text-teal-300'
                              : isMismatch
                              ? 'text-rose-400 font-bold'
                              : 'text-slate-300'
                          }`}
                        >
                          {item.sha256}
                        </span>
                        <button
                          onClick={() => handleCopy(item.sha256, `calc-${item.id}`)}
                          className="text-slate-500 hover:text-teal-300 p-1"
                          title="Copy hash"
                        >
                          {copiedId === `calc-${item.id}` ? (
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    </td>

                    {/* Recorded Hash (Editable) */}
                    <td className="py-3 px-4">
                      {editingId === item.id ? (
                        <div className="flex items-center gap-1">
                          <input
                            type="text"
                            value={editHashInput}
                            onChange={(e) => setEditHashInput(e.target.value)}
                            className="px-2 py-1 bg-slate-950 border border-teal-500 rounded text-[11px] font-mono text-slate-200 w-64"
                          />
                          <button
                            onClick={() => handleSaveBaseline(item.id, item.sha256)}
                            className="px-2 py-1 bg-teal-500 text-slate-950 rounded text-[10px] font-bold"
                          >
                            Save
                          </button>
                          <button
                            onClick={() => setEditingId(null)}
                            className="px-2 py-1 bg-slate-800 text-slate-400 rounded text-[10px]"
                          >
                            ✕
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1.5">
                          <span className="break-all text-[11px] text-slate-400 select-all">
                            {item.recordedHash || 'None recorded'}
                          </span>
                          <button
                            onClick={() => handleStartEditBaseline(item)}
                            className="text-slate-500 hover:text-teal-300 text-[10px] underline ml-1"
                          >
                            Edit
                          </button>
                        </div>
                      )}
                    </td>

                    {/* Verification Status Badge */}
                    <td className="py-3 px-4 text-center">
                      {isMatch && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[10px] font-bold">
                          <CheckCircle className="w-3 h-3" />
                          VERIFIED
                        </span>
                      )}
                      {isMismatch && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-rose-500/20 border border-rose-500/40 text-rose-400 text-[10px] font-bold animate-pulse">
                          <XCircle className="w-3 h-3" />
                          TAMPER / MISMATCH
                        </span>
                      )}
                      {!isMatch && !isMismatch && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-amber-500/10 border border-amber-500/30 text-amber-400 text-[10px] font-bold">
                          <AlertTriangle className="w-3 h-3" />
                          UNVERIFIED
                        </span>
                      )}
                    </td>

                    {/* Tamper Simulation Actions */}
                    <td className="py-3 px-4 text-right">
                      {isMismatch ? (
                        <button
                          onClick={() => onRestoreOriginal(item.id)}
                          className="px-2.5 py-1 rounded bg-teal-500/20 hover:bg-teal-500/30 border border-teal-500/40 text-teal-300 text-[10px] font-semibold transition"
                          title="Restore original verified state"
                        >
                          Restore Clean Hash
                        </button>
                      ) : (
                        <button
                          onClick={() => onSimulateTamper(item.id)}
                          className="px-2.5 py-1 rounded bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-300 text-[10px] transition"
                          title="Simulate 1-byte alteration to demonstrate hash avalanche effect"
                        >
                          Test Tamper Alert
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Standalone Interactive Hash Calculator & Comparator */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
          <Terminal className="w-5 h-5 text-teal-400" />
          <div>
            <h3 className="text-sm font-bold text-white">
              Interactive SHA-256 Calculator & Diff Comparator
            </h3>
            <p className="text-xs text-slate-400">
              Test any custom file or text string to calculate its cryptographic hash and check equality.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Input text or file */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-300">
                Data Input (Text or Raw Content):
              </label>
              <label className="text-[11px] text-teal-400 cursor-pointer hover:underline">
                <span>Or Upload File to Hash</span>
                <input
                  type="file"
                  onChange={handleToolFileDrop}
                  className="hidden"
                />
              </label>
            </div>
            <textarea
              rows={3}
              value={toolText}
              onChange={(e) => handleCalculateToolText(e.target.value)}
              placeholder="Paste text, log line, or drop a file to compute instant SHA-256..."
              className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-teal-500 font-mono"
            />
            {toolCalculatedHash && (
              <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 space-y-1">
                <span className="text-[10px] text-slate-400 uppercase font-mono">
                  Computed SHA-256 Digest:
                </span>
                <p className="text-xs font-mono text-teal-300 break-all select-all font-semibold">
                  {toolCalculatedHash}
                </p>
              </div>
            )}
          </div>

          {/* Target comparison hash */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300">
              Target Baseline Hash to Compare Against:
            </label>
            <input
              type="text"
              value={compareHashInput}
              onChange={(e) => setCompareHashInput(e.target.value)}
              placeholder="Paste 64-character SHA-256 hash here..."
              className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-teal-500 font-mono"
            />

            {/* Comparison Verdict */}
            {toolCalculatedHash && compareHashInput.trim() && (
              <div
                className={`p-3 rounded-lg border flex items-center gap-2.5 text-xs font-mono ${
                  toolMatch
                    ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300'
                    : 'bg-rose-950/40 border-rose-500/50 text-rose-300'
                }`}
              >
                {toolMatch ? (
                  <>
                    <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
                    <div>
                      <p className="font-bold">EXACT MATCH (100% BIT-LEVEL EQUIVALENT)</p>
                      <p className="text-[11px] text-emerald-400/80">
                        Cryptographic signature verifies the input data has not been modified.
                      </p>
                    </div>
                  </>
                ) : (
                  <>
                    <XCircle className="w-5 h-5 text-rose-400 shrink-0" />
                    <div>
                      <p className="font-bold">HASH MISMATCH DETECTED</p>
                      <p className="text-[11px] text-rose-300/80">
                        The hashes differ. Data alteration, bit rot, or invalid source baseline.
                      </p>
                    </div>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
