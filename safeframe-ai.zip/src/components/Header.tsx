import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  FileCheck2,
  Clock,
  Download,
  PlusCircle,
  RotateCcw,
  AlertTriangle,
  Cpu,
  Layers,
  Sparkles,
} from 'lucide-react';
import { IncidentCase } from '../types';

interface HeaderProps {
  currentCase: IncidentCase;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onResetSample: () => void;
  onOpenNewCaseModal: () => void;
  onOpenReportModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentCase,
  activeTab,
  setActiveTab,
  onResetSample,
  onOpenNewCaseModal,
  onOpenReportModal,
}) => {
  const [liveUtc, setLiveUtc] = useState<string>('');
  const [aiStatus, setAiStatus] = useState<{ checked: boolean; hasKey: boolean }>({
    checked: false,
    hasKey: false,
  });

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setLiveUtc(
        now.toISOString().replace('T', ' ').substring(0, 19) + ' UTC'
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    fetch('/api/health')
      .then((res) => res.json())
      .then((data) => {
        setAiStatus({ checked: true, hasKey: Boolean(data.hasApiKey) });
      })
      .catch(() => {
        setAiStatus({ checked: true, hasKey: false });
      });
  }, []);

  const totalEvidence = currentCase.evidence.length;
  const verifiedHashes = currentCase.evidence.filter(
    (e) => e.integrityStatus === 'verified'
  ).length;
  const totalTimeline = currentCase.timeline.length;

  const severityColors = {
    LOW: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
    MEDIUM: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
    HIGH: 'bg-orange-500/10 text-orange-400 border-orange-500/30',
    CRITICAL: 'bg-rose-500/10 text-rose-400 border-rose-500/30 animate-pulse',
  };

  const navItems = [
    { id: 'vault', label: 'Evidence Vault', count: totalEvidence },
    { id: 'analysis', label: 'AI Incident Analysis', badge: 'Gemini Vision' },
    { id: 'integrity', label: 'File Integrity', count: `${verifiedHashes}/${totalEvidence}` },
    { id: 'timeline', label: 'Incident Timeline', count: totalTimeline },
    { id: 'report', label: 'Incident Report', isAction: false },
  ];

  return (
    <header className="border-b border-slate-800 bg-[#091122]/95 backdrop-blur sticky top-0 z-40">
      {/* Top Banner: Brand, Case Selector, Live System Telemetry */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-4">
        {/* Logo & Tagline */}
        <div className="flex items-center space-x-3">
          <div className="relative flex items-center justify-center w-10 h-10 rounded-lg bg-gradient-to-br from-teal-500/20 to-teal-900/40 border border-teal-500/40 text-teal-300 shadow-lg shadow-teal-950/50">
            <ShieldAlert className="w-6 h-6 text-teal-400" />
            <span className="absolute -bottom-1 -right-1 w-2.5 h-2.5 rounded-full bg-teal-400 animate-ping opacity-75" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl font-bold tracking-tight text-white flex items-center gap-1">
                SafeFrame <span className="text-teal-400 font-extrabold">AI</span>
              </span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-teal-950 border border-teal-500/30 text-teal-300">
                v2.4 FORENSIC
              </span>
            </div>
            <p className="text-xs text-slate-400 font-medium">
              Preserve the Evidence. Understand the Incident.
            </p>
          </div>
        </div>

        {/* Case Info & Metadata Pill */}
        <div className="hidden lg:flex items-center gap-3 bg-slate-900/80 px-3.5 py-1.5 rounded-lg border border-slate-800 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-slate-400">Case:</span>
            <span className="font-mono font-semibold text-teal-300">
              {currentCase.caseNumber}
            </span>
          </div>
          <span className="text-slate-600">|</span>
          <span className="text-slate-300 max-w-[200px] truncate" title={currentCase.title}>
            {currentCase.title}
          </span>
          <span
            className={`px-2 py-0.5 rounded text-[11px] font-bold border ${
              severityColors[currentCase.severity] || severityColors.HIGH
            }`}
          >
            {currentCase.severity} PRIORITY
          </span>
        </div>

        {/* Action Controls & Telemetry */}
        <div className="flex items-center gap-2">
          {/* UTC Clock */}
          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-slate-400 font-mono text-xs">
            <Clock className="w-3.5 h-3.5 text-teal-400" />
            <span>{liveUtc}</span>
          </div>

          {/* AI Status */}
          <div
            className={`hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded border text-xs font-mono ${
              aiStatus.hasKey
                ? 'bg-teal-950/40 border-teal-500/40 text-teal-300'
                : 'bg-slate-900 border-slate-800 text-slate-400'
            }`}
            title={
              aiStatus.hasKey
                ? 'Gemini Multimodal Vision API is active'
                : 'Gemini API initialized (system secrets)'
            }
          >
            <Cpu className="w-3.5 h-3.5 text-teal-400" />
            <span>Gemini Vision</span>
          </div>

          {/* Sample reset */}
          <button
            onClick={onResetSample}
            title="Reset to default CCTV sample dataset"
            className="p-1.5 text-slate-400 hover:text-teal-300 hover:bg-slate-800/80 rounded border border-transparent hover:border-slate-700 transition"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {/* New Case Button */}
          <button
            onClick={onOpenNewCaseModal}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
          >
            <PlusCircle className="w-3.5 h-3.5 text-teal-400" />
            <span className="hidden sm:inline">New Case</span>
          </button>

          {/* Generate Report Quick Button */}
          <button
            onClick={onOpenReportModal}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded bg-teal-500 hover:bg-teal-400 text-slate-950 shadow-sm shadow-teal-500/30 transition"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Report</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 flex overflow-x-auto gap-1 border-t border-slate-800/60 no-scrollbar">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex items-center gap-2 py-2.5 px-3.5 text-xs font-medium border-b-2 whitespace-nowrap transition-colors ${
                isActive
                  ? 'border-teal-400 text-teal-300 bg-teal-500/5'
                  : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
              }`}
            >
              <span>{item.label}</span>
              {item.count !== undefined && (
                <span
                  className={`px-1.5 py-0.5 rounded-full text-[10px] font-mono ${
                    isActive
                      ? 'bg-teal-500/20 text-teal-300'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {item.count}
                </span>
              )}
              {item.badge && (
                <span className="flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[10px] font-mono bg-teal-950/60 text-teal-300 border border-teal-500/30">
                  <Sparkles className="w-2.5 h-2.5 text-teal-400" />
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </header>
  );
};
