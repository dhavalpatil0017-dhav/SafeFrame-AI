import React, { useState } from 'react';
import { PlusCircle, ShieldAlert } from 'lucide-react';
import { IncidentCase, ThreatLevel } from '../types';

interface NewCaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateCase: (newCase: IncidentCase) => void;
}

export const NewCaseModal: React.FC<NewCaseModalProps> = ({
  isOpen,
  onClose,
  onCreateCase,
}) => {
  const [caseNumber, setCaseNumber] = useState(
    `SF-${Math.floor(1000 + Math.random() * 9000)}-SEC`
  );
  const [title, setTitle] = useState('');
  const [facility, setFacility] = useState('Primary Corporate Headquarters');
  const [leadInvestigator, setLeadInvestigator] = useState('Agent J. Reynolds');
  const [badgeNumber, setBadgeNumber] = useState('SEC-4190');
  const [severity, setSeverity] = useState<ThreatLevel>('HIGH');
  const [description, setDescription] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const newCase: IncidentCase = {
      id: `case-${Date.now()}`,
      caseNumber: caseNumber.trim(),
      title: title.trim(),
      facility: facility.trim(),
      leadInvestigator: leadInvestigator.trim(),
      badgeNumber: badgeNumber.trim(),
      status: 'OPEN',
      severity,
      incidentDate: new Date().toISOString(),
      description: description.trim() || 'Physical security incident under active investigation.',
      evidence: [],
      timeline: [
        {
          id: `tl-${Date.now()}`,
          timestamp: new Date().toISOString(),
          title: 'Case File Initialized',
          description: `Case ${caseNumber} created in SafeFrame AI by ${leadInvestigator}.`,
          type: 'INVESTIGATOR_NOTE',
          source: 'SafeFrame AI System',
          verified: true,
          severity: 'LOW',
        },
      ],
    };

    onCreateCase(newCase);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <form
        onSubmit={handleSubmit}
        className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl"
      >
        <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
          <ShieldAlert className="w-5 h-5 text-teal-400" />
          <h3 className="text-base font-bold text-white">Create New Incident Case File</h3>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-300">Case Reference ID</label>
            <input
              type="text"
              required
              value={caseNumber}
              onChange={(e) => setCaseNumber(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs font-mono text-teal-300 focus:outline-none focus:border-teal-500"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-300">Initial Severity</label>
            <select
              value={severity}
              onChange={(e) => setSeverity(e.target.value as ThreatLevel)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-teal-500"
            >
              <option value="LOW">Low</option>
              <option value="MEDIUM">Medium</option>
              <option value="HIGH">High</option>
              <option value="CRITICAL">Critical</option>
            </select>
          </div>
        </div>

        <div className="space-y-1">
          <label className="text-xs font-medium text-slate-300">Incident Title</label>
          <input
            type="text"
            required
            placeholder="e.g. Loading Dock Unauthorized Vehicle Presence"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-teal-500"
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-300">Facility / Location</label>
            <input
              type="text"
              value={facility}
              onChange={(e) => setFacility(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-teal-500"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-300">Lead Investigator</label>
            <input
              type="text"
              value={leadInvestigator}
              onChange={(e) => setLeadInvestigator(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-teal-500"
            />
          </div>
        </div>

        <div className="space-y-1">
          <label className="text-xs font-medium text-slate-300">Incident Synopsis / Initial Report</label>
          <textarea
            rows={3}
            placeholder="Brief overview of alarms or reports triggering this investigation..."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-teal-500"
          />
        </div>

        <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-1.5 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-950 font-semibold text-xs transition"
          >
            Initialize Case File
          </button>
        </div>
      </form>
    </div>
  );
};
