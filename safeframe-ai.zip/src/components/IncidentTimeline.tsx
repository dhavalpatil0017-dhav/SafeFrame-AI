import React, { useState } from 'react';
import {
  Clock,
  PlusCircle,
  Camera,
  KeyRound,
  BellRing,
  Shield,
  FileEdit,
  Hash,
  CheckCircle,
  Filter,
  Trash2,
  Calendar,
  ExternalLink,
} from 'lucide-react';
import { TimelineEvent, EvidenceFile, ThreatLevel } from '../types';
import { formatCCTVTimestamp, formatTimeOnly, getTimeDelta } from '../utils/crypto';

interface IncidentTimelineProps {
  timeline: TimelineEvent[];
  evidence: EvidenceFile[];
  onAddEvent: (event: TimelineEvent) => void;
  onDeleteEvent: (id: string) => void;
  onViewEvidence: (evidenceId: string) => void;
}

export const IncidentTimeline: React.FC<IncidentTimelineProps> = ({
  timeline,
  evidence,
  onAddEvent,
  onDeleteEvent,
  onViewEvidence,
}) => {
  const [filterType, setFilterType] = useState<string>('ALL');
  const [showAddModal, setShowAddModal] = useState<boolean>(false);

  // New Event Form State
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [type, setType] = useState<TimelineEvent['type']>('INVESTIGATOR_NOTE');
  const [timestamp, setTimestamp] = useState(new Date().toISOString().slice(0, 19));
  const [source, setSource] = useState('Lead Investigator');
  const [linkedEvidenceId, setLinkedEvidenceId] = useState<string>('');
  const [severity, setSeverity] = useState<ThreatLevel>('MEDIUM');

  // Sort events chronologically
  const sortedTimeline = [...timeline].sort(
    (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
  );

  const filteredEvents = sortedTimeline.filter(
    (ev) => filterType === 'ALL' || ev.type === filterType
  );

  const eventTypeIcons: Record<TimelineEvent['type'], React.ReactNode> = {
    CCTV_DETECTION: <Camera className="w-4 h-4 text-teal-400" />,
    BADGE_ACCESS: <KeyRound className="w-4 h-4 text-cyan-400" />,
    ALARM_TRIGGER: <BellRing className="w-4 h-4 text-rose-400" />,
    OFFICER_PATROL: <Shield className="w-4 h-4 text-indigo-400" />,
    INVESTIGATOR_NOTE: <FileEdit className="w-4 h-4 text-amber-400" />,
    HASH_VERIFICATION: <Hash className="w-4 h-4 text-emerald-400" />,
  };

  const eventTypeLabels: Record<TimelineEvent['type'], string> = {
    CCTV_DETECTION: 'CCTV Detection',
    BADGE_ACCESS: 'Badge Reader Access',
    ALARM_TRIGGER: 'Sensor / Alarm Trip',
    OFFICER_PATROL: 'Security Patrol Log',
    INVESTIGATOR_NOTE: 'Investigator Note',
    HASH_VERIFICATION: 'Evidence Hash Verified',
  };

  const handleCreateEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const newEvent: TimelineEvent = {
      id: `tl-${Date.now()}`,
      title: title.trim(),
      description: description.trim(),
      type,
      timestamp: new Date(timestamp).toISOString(),
      source: source.trim() || 'Physical Security Team',
      evidenceId: linkedEvidenceId || undefined,
      verified: true,
      severity,
    };

    onAddEvent(newEvent);
    setShowAddModal(false);
    setTitle('');
    setDescription('');
    setLinkedEvidenceId('');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900/60 p-4 rounded-xl border border-slate-800">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Clock className="w-5 h-5 text-teal-400" />
            Verified Incident Timeline
          </h2>
          <p className="text-xs text-slate-400">
            Chronological reconstruction of CCTV frame captures, sensor triggers, and investigator notes.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Filter by Type */}
          <div className="relative">
            <Filter className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="pl-8 pr-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-teal-500"
            >
              <option value="ALL">All Event Types ({timeline.length})</option>
              <option value="CCTV_DETECTION">CCTV Detections</option>
              <option value="ALARM_TRIGGER">Sensor / Alarm Trips</option>
              <option value="BADGE_ACCESS">Badge Reader Logs</option>
              <option value="INVESTIGATOR_NOTE">Investigator Notes</option>
              <option value="HASH_VERIFICATION">Hash Verifications</option>
            </select>
          </div>

          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-950 font-semibold text-xs shadow-sm transition"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>Add Event / Note</span>
          </button>
        </div>
      </div>

      {/* Chronological Timeline Stream */}
      <div className="relative pl-6 sm:pl-8 space-y-6 before:absolute before:left-3 sm:before:left-4 before:top-3 before:bottom-3 before:w-0.5 before:bg-slate-800">
        {filteredEvents.map((item, index) => {
          const linkedEvidence = evidence.find((e) => e.id === item.evidenceId);
          const prevItem = index > 0 ? filteredEvents[index - 1] : null;
          const delta = prevItem ? getTimeDelta(prevItem.timestamp, item.timestamp) : null;

          return (
            <div key={item.id} className="relative group">
              {/* Event Node Icon on Vertical Spine */}
              <div className="absolute -left-6 sm:-left-8 top-1.5 w-6 h-6 sm:w-8 sm:h-8 rounded-full bg-slate-900 border-2 border-slate-700 flex items-center justify-center shadow-lg group-hover:border-teal-400 transition">
                {eventTypeIcons[item.type] || <Clock className="w-3.5 h-3.5 text-slate-400" />}
              </div>

              {/* Time Delta Pill between events */}
              {delta && delta !== '+00:00' && (
                <div className="mb-2 -mt-3 flex items-center gap-1 text-[10px] font-mono text-teal-400/80">
                  <span className="px-2 py-0.5 rounded-full bg-slate-950 border border-slate-800">
                    Δ {delta}
                  </span>
                </div>
              )}

              {/* Card Body */}
              <div className="bg-slate-900/80 border border-slate-800 hover:border-slate-700 rounded-xl p-4 transition shadow-sm space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-teal-300">
                      {formatTimeOnly(item.timestamp)}
                    </span>
                    <span className="text-[11px] font-mono text-slate-500">
                      ({formatCCTVTimestamp(item.timestamp)})
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-950 border border-slate-800 text-slate-300">
                      {eventTypeLabels[item.type]}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    {item.verified && (
                      <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1">
                        <CheckCircle className="w-3 h-3" />
                        VERIFIED TIMESTAMP
                      </span>
                    )}
                    <button
                      onClick={() => onDeleteEvent(item.id)}
                      title="Remove event"
                      className="text-slate-600 hover:text-rose-400 p-1 rounded transition"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold text-sm text-white">{item.title}</h3>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                    {item.description}
                  </p>
                </div>

                {/* Source Attribution & Linked CCTV Frame */}
                <div className="pt-2 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-xs">
                  <span className="text-slate-400 font-mono text-[11px]">
                    Source: <strong className="text-slate-300">{item.source}</strong>
                  </span>

                  {linkedEvidence && (
                    <button
                      onClick={() => onViewEvidence(linkedEvidence.id)}
                      className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-teal-500/10 hover:bg-teal-500/20 border border-teal-500/30 text-teal-300 font-mono text-[11px] transition"
                    >
                      <Camera className="w-3 h-3" />
                      <span>Inspect Linked Frame: {linkedEvidence.cameraSource.split(':')[0]}</span>
                      <ExternalLink className="w-2.5 h-2.5" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filteredEvents.length === 0 && (
        <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-8 text-center text-slate-400">
          <p className="text-sm">No timeline events match the selected filter.</p>
        </div>
      )}

      {/* Add Event Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleCreateEvent}
            className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl"
          >
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Clock className="w-5 h-5 text-teal-400" />
              Add Timeline Event / Note
            </h3>

            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-300">Event Title</label>
              <input
                type="text"
                required
                placeholder="e.g., Security Guard Dispatched to Gate 3"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-teal-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-medium text-slate-300">Event Type</label>
                <select
                  value={type}
                  onChange={(e) => setType(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-teal-500"
                >
                  <option value="INVESTIGATOR_NOTE">Investigator Note</option>
                  <option value="CCTV_DETECTION">CCTV Detection</option>
                  <option value="ALARM_TRIGGER">Sensor Alarm Trigger</option>
                  <option value="BADGE_ACCESS">Badge Reader Log</option>
                  <option value="OFFICER_PATROL">Officer Patrol</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-medium text-slate-300">Severity</label>
                <select
                  value={severity}
                  onChange={(e) => setSeverity(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-teal-500"
                >
                  <option value="LOW">Low</option>
                  <option value="MEDIUM">Medium</option>
                  <option value="HIGH">High</option>
                  <option value="CRITICAL">Critical</option>
                </select>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-300">Timestamp</label>
              <input
                type="datetime-local"
                value={timestamp}
                onChange={(e) => setTimestamp(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-teal-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-300">Source / Device / Investigator</label>
              <input
                type="text"
                placeholder="e.g. Milestone XProtect / Guard Report"
                value={source}
                onChange={(e) => setSource(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-teal-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-300">Link to Evidence Frame (Optional)</label>
              <select
                value={linkedEvidenceId}
                onChange={(e) => setLinkedEvidenceId(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-teal-500"
              >
                <option value="">No linked evidence</option>
                {evidence.map((ev) => (
                  <option key={ev.id} value={ev.id}>
                    {ev.name} ({ev.cameraSource})
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-300">Detailed Description / Notes</label>
              <textarea
                rows={3}
                placeholder="Explain what occurred or what was observed..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-teal-500"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-950 font-semibold text-xs transition"
              >
                Record Timeline Event
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
