/**
 * Cryptographic and formatting utilities for SafeFrame AI
 * Uses browser Web Crypto API for SHA-256 calculation
 */

export async function calculateArrayBufferHash(buffer: ArrayBuffer): Promise<string> {
  const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

export async function calculateFileHash(file: File): Promise<string> {
  const buffer = await file.arrayBuffer();
  return calculateArrayBufferHash(buffer);
}

export async function calculateStringHash(text: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(text);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

export function compareHashes(hashA: string, hashB: string): boolean {
  if (!hashA || !hashB) return false;
  return hashA.trim().toLowerCase() === hashB.trim().toLowerCase();
}

export function formatBytes(bytes: number, decimals: number = 2): string {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

export function formatCCTVTimestamp(isoString: string): string {
  try {
    const d = new Date(isoString);
    if (isNaN(d.getTime())) return isoString;
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const hours = String(d.getHours()).padStart(2, '0');
    const minutes = String(d.getMinutes()).padStart(2, '0');
    const seconds = String(d.getSeconds()).padStart(2, '0');
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
  } catch {
    return isoString;
  }
}

export function formatTimeOnly(isoString: string): string {
  try {
    const d = new Date(isoString);
    if (isNaN(d.getTime())) return isoString;
    return d.toLocaleTimeString('en-US', {
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  } catch {
    return isoString;
  }
}

export function getTimeDelta(fromIso: string, toIso: string): string {
  try {
    const t1 = new Date(fromIso).getTime();
    const t2 = new Date(toIso).getTime();
    const diffSec = Math.floor(Math.abs(t2 - t1) / 1000);
    const m = Math.floor(diffSec / 60);
    const s = diffSec % 60;
    return `+${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  } catch {
    return '';
  }
}

/**
 * Optimizes and resizes any image (including SVGs, large 4K JPEGs, and PNGs)
 * down to max dimensions (default 1024px) for fast and reliable Gemini Vision analysis.
 * Dramatically reduces upload payload and prevents API timeouts.
 */
export async function optimizeImageForAnalysis(
  dataUrl: string,
  maxDimension: number = 1024,
  quality: number = 0.88
): Promise<{ dataUrl: string; mimeType: string; originalSize: number; optimizedSize: number }> {
  const originalSize = Math.round((dataUrl.length * 3) / 4);

  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';

    img.onload = () => {
      let { width, height } = img;

      // Handle SVG with unspecified natural width/height
      if (!width || !height || width <= 0 || height <= 0) {
        width = 800;
        height = 450;
      }

      // Calculate scaled dimensions while preserving aspect ratio
      if (width > maxDimension || height > maxDimension) {
        if (width > height) {
          height = Math.round((height * maxDimension) / width);
          width = maxDimension;
        } else {
          width = Math.round((width * maxDimension) / height);
          height = maxDimension;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = Math.max(width, 100);
      canvas.height = Math.max(height, 100);

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve({
          dataUrl,
          mimeType: 'image/jpeg',
          originalSize,
          optimizedSize: originalSize,
        });
        return;
      }

      // Fill dark CCTV neutral background for transparent areas
      ctx.fillStyle = '#070c18';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

      // Export as high-quality JPEG for fast network transit
      const optimizedDataUrl = canvas.toDataURL('image/jpeg', quality);
      const optimizedSize = Math.round((optimizedDataUrl.length * 3) / 4);

      resolve({
        dataUrl: optimizedDataUrl,
        mimeType: 'image/jpeg',
        originalSize,
        optimizedSize,
      });
    };

    img.onerror = () => {
      // Fallback to original
      resolve({
        dataUrl,
        mimeType: dataUrl.startsWith('data:image/png') ? 'image/png' : 'image/jpeg',
        originalSize,
        optimizedSize: originalSize,
      });
    };

    img.src = dataUrl;
  });
}

// Backward compatible alias
export const ensureRasterImage = optimizeImageForAnalysis;

